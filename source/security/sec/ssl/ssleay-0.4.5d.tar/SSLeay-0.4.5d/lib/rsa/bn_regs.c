/* lib/rsa/bn_regs.c */
/* Copyright (C) 1995 Eric Young (eay@mincom.oz.au)
 * All rights reserved.
 * 
 * This file is part of an SSL implementation written
 * by Eric Young (eay@mincom.oz.au).
 * The implementation was written so as to conform with Netscapes SSL
 * specification.  This library and applications are
 * FREE FOR COMMERCIAL AND NON-COMMERCIAL USE
 * as long as the following conditions are aheared to.
 * 
 * Copyright remains Eric Young's, and as such any Copyright notices in
 * the code are not to be removed.  If this code is used in a product,
 * Eric Young should be given attribution as the author of the parts used.
 * This can be in the form of a textual message at program startup or
 * in documentation (online or textual) provided with the package.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by Eric Young (eay@mincom.oz.au)
 * 
 * THIS SOFTWARE IS PROVIDED BY ERIC YOUNG ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * 
 * The licence and distribution terms for any publically available version or
 * derivative of this code cannot be changed.  i.e. this code cannot simply be
 * copied and put under another distribution licence
 * [including the GNU Public Licence.]
 */

#include <stdio.h>
#include "crypto.h"
#include "bn.h"

#define REG_INC	8

static int num_regs=0;
static int bn_tos=0;
static BIGNUM **regs=NULL;

void bn_clean_up()
	{
	int i,j;
	BN_ULONG *d;

	for (i=bn_tos; i<num_regs; i++)
		{
		d=regs[i]->d;
		for (j=regs[i]->max-1; j>=0; j--)
			d[j]=0;
		bn_free(regs[i]);
		regs[i]=NULL;
		}
	num_regs=bn_tos;
	}

int bn_get_tos()
	{
	return(bn_tos);
	}

void bn_set_tos(a)
int a;
	{
	bn_tos=a;
	}

BIGNUM *bn_get_reg()
	{
	int i;

	if (regs == NULL)
		{
		num_regs=0;
		regs=(BIGNUM **)malloc(sizeof(BIGNUM *)*1);
		if (regs == NULL) goto err;
		bn_tos=0;
		}
	if (bn_tos >= num_regs)
		{
		i=num_regs;
		num_regs+=REG_INC;
		regs=(BIGNUM **)realloc(regs,sizeof(BIGNUM *)*num_regs);
		if (regs == NULL) goto err;
		for (; i<num_regs; i++)
			{
			regs[i]=bn_new();
			if (regs[i] == NULL) goto err;
			}
		}
	return(regs[bn_tos++]);
err:
	RSAerr(RSA_F_BN_GET_REG,ERR_R_MALLOC_FAILURE);
	return(NULL);
	}

