/* lib/ssl/ssl.h */
/* Copyright (C) 1995 Eric Young (eay@mincom.oz.au)
 * All rights reserved.
 * 
 * This file is part of an SSL implementation written
 * by Eric Young (eay@mincom.oz.au).
 * The implementation was written so as to conform with Netscapes SSL
 * specification.  This library and applications are
 * FREE FOR COMMERCIAL AND NON-COMMERCIAL USE
 * as long as the following conditions are aheared to.
 * 
 * Copyright remains Eric Young's, and as such any Copyright notices in
 * the code are not to be removed.  If this code is used in a product,
 * Eric Young should be given attribution as the author of the parts used.
 * This can be in the form of a textual message at program startup or
 * in documentation (online or textual) provided with the package.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by Eric Young (eay@mincom.oz.au)
 * 
 * THIS SOFTWARE IS PROVIDED BY ERIC YOUNG ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * 
 * The licence and distribution terms for any publically available version or
 * derivative of this code cannot be changed.  i.e. this code cannot simply be
 * copied and put under another distribution licence
 * [including the GNU Public Licence.]
 */

#ifndef HEADER_SSL_H 
#define HEADER_SSL_H 

/* Protocol Version Codes */
#define SSL_CLIENT_VERSION	0x0002
#define SSL_SERVER_VERSION	0x0002

/* Protocol Message Codes */
#define SSL_MT_ERROR			0
#define SSL_MT_CLIENT_HELLO		1
#define SSL_MT_CLIENT_MASTER_KEY	2
#define SSL_MT_CLIENT_FINISHED		3
#define SSL_MT_SERVER_HELLO		4
#define SSL_MT_SERVER_VERIFY		5
#define SSL_MT_SERVER_FINISHED		6
#define SSL_MT_REQUEST_CERTIFICATE	7
#define SSL_MT_CLIENT_CERTIFICATE	8

/* Error Message Codes */
#define SSL_PE_NO_CIPHER		0x0001
#define SSL_PE_NO_CERTIFICATE		0x0002
#define SSL_PE_BAD_CERTIFICATE		0x0004
#define SSL_PE_UNSUPPORTED_CERTIFICATE_TYPE 0x0006

/* Cipher Kind Values */
#define SSL_CK_NULL_WITH_MD5			0x00,0x00,0x00 /* v3 */
#define SSL_CK_RC4_128_WITH_MD5			0x01,0x00,0x80
#define SSL_CK_RC4_128_EXPORT40_WITH_MD5	0x02,0x00,0x80
#define SSL_CK_RC2_128_CBC_WITH_MD5		0x03,0x00,0x80
#define SSL_CK_RC2_128_CBC_EXPORT40_WITH_MD5	0x04,0x00,0x80
#define SSL_CK_IDEA_128_CBC_WITH_MD5		0x05,0x00,0x80
#define SSL_CK_DES_64_CBC_WITH_MD5		0x06,0x00,0x40
#define SSL_CK_DES_64_CBC_WITH_SHA		0x06,0x01,0x40 /* v3 */
#define SSL_CK_DES_192_EDE3_CBC_WITH_MD5	0x07,0x00,0xc0
#define SSL_CK_DES_192_EDE3_CBC_WITH_SHA	0x07,0x01,0xc0 /* v3 */

#define SSL_CK_DES_64_CFB64_WITH_MD5_1		0xff,0x08,0x00 /* SSLeay */

/* text strings for the ciphers */
#define SSL_TXT_NULL_WITH_MD5			"NULL-MD5"
#define SSL_TXT_RC4_128_WITH_MD5		"RC4-MD5"
#define SSL_TXT_RC4_128_EXPORT40_WITH_MD5	"EXP-RC4-MD5"
#define SSL_TXT_RC2_128_CBC_WITH_MD5		"RC2-MD5"
#define SSL_TXT_RC2_128_CBC_EXPORT40_WITH_MD5	"EXP-RC2-MD5"
#define SSL_TXT_IDEA_128_CBC_WITH_MD5		"CBC-IDEA-MD5"
#define SSL_TXT_DES_64_CBC_WITH_MD5		"CBC-DES-MD5"
#define SSL_TXT_DES_192_EDE3_CBC_WITH_MD5	"CBC3-DES-MD5"

#define SSL_TXT_DES_64_CFB64_WITH_MD5_1		"CFB-DES-M1"

/* Certificate Type Codes */
#define SSL_CT_X509_CERTIFICATE			0x01

/* Authentication Type Code */
#define SSL_AT_MD5_WITH_RSA_ENCRYPTION		0x01

/* Upper/Lower Bounds */
#define SSL_MAX_MASTER_KEY_LENGTH_IN_BITS	256
#define SSL_MAX_SESSION_ID_LENGTH_IN_BYTES	16
#define SSL_MIN_RSA_MODULUS_LENGTH_IN_BYTES	64
#define SSL_MAX_RECORD_LENGTH_2_BYTE_HEADER	32767 
#define SSL_MAX_RECORD_LENGTH_3_BYTE_HEADER	16383 /**/

#ifndef HEADER_X509_H
#define X509	char
#define RSA	char
#endif

typedef struct ssl_state_st
	{
	/* used by ssl_read */
	int fd;
	int version;	/* procol version */

	int state;	/* where we are */
	unsigned int state_conn_id_length;	/* tmp */
	unsigned int state_cert_type;		/* tmp */
	unsigned int state_cert_length;		/* tmp */
	unsigned int state_csl; 		/* tmp */

	unsigned int state_clear; 		/* tmp */
	unsigned int state_enc; 		/* tmp */

	unsigned char *state_ccl;		/* tmp */

	unsigned int state_cipher_spec_length;
	unsigned int state_session_id_length;

	unsigned int state_clen;
	unsigned int state_rlen;

	int rstate;	/* where we are when reading */

	unsigned char *init_buf;/* buffer used during init */
	int init_num;	/* amount read/written */
	int init_off;	/* amount read/written */

	int read_ahead;
	int escape;
	int three_byte_header;
	int send;		/* direction of packet */
	int clear_text;		/* clear text */
	int hit;		/* reusing a previous session */

	/* non-blocking io info, used to make sure the same args were passwd */
	int wpend_tot;
	char *wpend_buf;

	int wpend_off;		/* offset to data to write */
	int wpend_len;  	/* number of bytes passwd to write */
	int wpend_ret;  	/* number of bytes to return to caller */

	int rpend_off;		/* offset to read position */
	int rpend_len;		/* number of bytes to read */

	/* buffer raw data */
	int rbuf_left;
	int rbuf_offs;
	unsigned char *rbuf;
	unsigned char *wbuf;

	/* used internally by ssl_read to talk to read_n */
	unsigned char *packet;
	unsigned int packet_length;

	/* set by read_n */
	unsigned int length;
	unsigned int padding;
	unsigned int ract_data_length; /* Set when things are encrypted. */
	unsigned int wact_data_length; /* Set when things are decrypted. */
	unsigned char *ract_data;
	unsigned char *wact_data;
	unsigned char *mac_data;
	unsigned char *pad_data;

	/* crypto */
	int num_pref_cipher;
	char **pref_cipher;	/* char ** is malloced and the rest is
				 * on malloced block pointed to by
				 * perf_cipher[0] */
	char *crypt_state;	/* cryptographic state */
	unsigned char *read_key;
	unsigned char *write_key;

	/* conn info */
#ifdef HEADER_SSL_LOCL_H
	CONN *conn;
	CERT *cert;
#else
	char *conn;
	char *cert;
#endif

	unsigned int challenge_length;
	unsigned char *challenge;
	unsigned int conn_id_length;
	unsigned char *conn_id;

	/* packet specs */
	/* send is true for send; false for recieve */

	unsigned char *write_ptr;	/* used to point to the start due to
					 * 2/3 byte header. */

	unsigned long read_sequence;
	unsigned long write_sequence;

	/* special stuff */
	int trust_level;	/* not used yet */
	int peer_status;	/* 0, not set, 1 in ->perr, 2 in
				 * ->conn->cert->x509 */
#ifdef HEADER_X509_H
	X509 *peer;
#else
	char *peer;		/* actually a X509 * */
#endif
	int verify_mode;	/* 0 don't care about verify failure.
				 * 1 fail if verify fails */
	int (*verify_callback)(); /* fail if callback returns 0 */
	} SSL;

#define SSL_VERIFY_NONE			0x00
#define SSL_VERIFY_PEER			0x01
#define SSL_VERIFY_FAIL_IF_NO_PEER_CERT	0x02

#define SSL_RWERR_BAD_WRITE_RETRY	(-2)
#define SSL_RWERR_BAD_MAC_DECODE	(-3)
#define SSL_RWERR_INTERNAL_ERROR	(-4) /* should not get this one */

#ifdef PROTO
int	SSL_accept(SSL *s);
void	SSL_clear(SSL *s);
int	SSL_connect(SSL *s);
int	SSL_copy_session_id(SSL *to, SSL *from);
void	SSL_debug(char *file);
void	SSL_flush_connections(void);
void	SSL_free(SSL *s);
char *	SSL_get_cipher(SSL *s);
int	SSL_get_fd(SSL *s);
char *	SSL_get_pref_cipher(SSL *s, int n);
char *	SSL_get_shared_ciphers(SSL *s, char *buf, int len);
int	SSL_get_read_ahead(SSL * s);
long	SSL_get_time(SSL * s);
long	SSL_get_timeout(SSL * s);
int	SSL_is_init_finished(SSL *s);
SSL *	SSL_new(void);
int	SSL_pending(SSL *s);
int	SSL_read(SSL *s, char *buf, unsigned int len);
void	SSL_set_fd(SSL *s, int fd);
int	SSL_set_pref_cipher(SSL *s, char *str);
void	SSL_set_read_ahead(SSL * s, int yes);
int	SSL_set_timeout(SSL * s, int t);
void	SSL_set_verify(SSL *s, int mode, int (*callback) ());
int	SSL_use_RSAPrivateKey(SSL *ssl, RSA *rsa);
int	SSL_use_RSAPrivateKey_DER(SSL *ssl, int len, unsigned char *d);
int	SSL_use_RSAPrivateKey_file(SSL *ssl, char *file, int type);
int	SSL_use_certificate(SSL *ssl, X509 *x);
int	SSL_use_certificate_DER(SSL *ssl, int len, unsigned char *d);
int	SSL_use_certificate_file(SSL *ssl, char *file, int type);
int	SSL_write(SSL *s, char *buf, unsigned int len);
void	ERR_load_SSL_strings(void );
void	SSL_load_error_strings(void );
#ifdef HEADER_X509_H
X509 *	SSL_get_peer_certificate(SSL *s);
#else
char *	SSL_get_peer_certificate(SSL *s);
#endif
#else
int	SSL_accept();
void	SSL_clear();
int	SSL_connect();
int	SSL_copy_session_id();
void	SSL_debug();
void	SSL_flush_connections();
void	SSL_free();
char *	SSL_get_cipher();
int	SSL_get_fd();
char *	SSL_get_pref_cipher();
int	SSL_get_read_ahead();
long	SSL_get_time();
long	SSL_get_timeout();
int	SSL_is_init_finished();
SSL *	SSL_new();
int	SSL_pending();
int	SSL_read();
void	SSL_set_fd();
int	SSL_set_pref_cipher();
char *	SSL_get_shared_ciphers();
void	SSL_set_read_ahead();
int	SSL_set_timeout();
void	SSL_set_verify();
int	SSL_use_RSAPrivateKey();
int	SSL_use_RSAPrivateKey_DER();
int	SSL_use_RSAPrivateKey_file();
int	SSL_use_certificate();
int	SSL_use_certificate_DER();
int	SSL_use_certificate_file();
int	SSL_write();
void	ERR_load_SSL_strings();
void	SSL_load_error_strings();
#ifdef HEADER_X509_H
X509 *	SSL_get_peer_certificate();
#else
char *	SSL_get_peer_certificate();
#endif
#endif

/* tjh added these two dudes to enable external control
 * of debug and trace logging
 */
extern FILE *SSL_ERR;
extern FILE *SSL_LOG;

#endif /* HEADER_SSL_H */

