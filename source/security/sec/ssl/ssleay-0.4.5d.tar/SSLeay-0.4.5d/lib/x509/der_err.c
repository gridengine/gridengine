/* lib/x509/der_err.c */
/* Copyright (C) 1995 Eric Young (eay@mincom.oz.au)
 * All rights reserved.
 * 
 * This file is part of an SSL implementation written
 * by Eric Young (eay@mincom.oz.au).
 * The implementation was written so as to conform with Netscapes SSL
 * specification.  This library and applications are
 * FREE FOR COMMERCIAL AND NON-COMMERCIAL USE
 * as long as the following conditions are aheared to.
 * 
 * Copyright remains Eric Young's, and as such any Copyright notices in
 * the code are not to be removed.  If this code is used in a product,
 * Eric Young should be given attribution as the author of the parts used.
 * This can be in the form of a textual message at program startup or
 * in documentation (online or textual) provided with the package.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by Eric Young (eay@mincom.oz.au)
 * 
 * THIS SOFTWARE IS PROVIDED BY ERIC YOUNG ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * 
 * The licence and distribution terms for any publically available version or
 * derivative of this code cannot be changed.  i.e. this code cannot simply be
 * copied and put under another distribution licence
 * [including the GNU Public Licence.]
 */

#include <stdio.h>
#include "crypto.h"
#include "x509.h"

static ERR_STRING_DATA DER_str_functs[]=
	{
{ERR_PACK(0,DER_F_D2I_X509_ALGOR,0),	"D2i_X509_ALGOR"},
{ERR_PACK(0,DER_F_D2I_X509_NAME,0),	"D2i_X509_NAME"},
{ERR_PACK(0,DER_F_D2I_X509_VAL,0),	"D2i_X509_VAL"},
{ERR_PACK(0,DER_F_D2I_X509_PUBKEY,0),	"D2i_X509_PUBKEY"},
{ERR_PACK(0,DER_F_D2I_X509_SIG,0),	"D2i_X509_SIG"},
{ERR_PACK(0,DER_F_D2I_X509_CINF,0),	"D2i_X509_CINF"},
{ERR_PACK(0,DER_F_D2I_X509_REVOKED,0),	"D2i_X509_REVOKED"},
{ERR_PACK(0,DER_F_D2I_X509_REVOKED_LIST,0),	"D2I_X509_REVOKED_LIST"},
{ERR_PACK(0,DER_F_D2I_X509_CRL_INFO,0),	"D2i_X509_CRL_INFO"},
{ERR_PACK(0,DER_F_D2I_X509_CRL,0),	"D2i_X509_CRL"},
{ERR_PACK(0,DER_F_D2I_X509_CRL_FILE,0),	"D2i_X509_CRL_file"},
{ERR_PACK(0,DER_F_D2I_X509_CRL_FP,0),	"D2i_X509_CRL_fp"},
{ERR_PACK(0,DER_F_D2I_X509_FILE,0),	"D2i_X509_file"},
{ERR_PACK(0,DER_F_D2I_X509_FP,0),	"D2i_X509_fp"},
{ERR_PACK(0,DER_F_D2I_X509,0),	"D2i_X509"},
{ERR_PACK(0,DER_F_D2I_RSAPRIVATEKEY_FP,0),	"D2i_RSAPrivateKey_fp"},
{ERR_PACK(0,DER_F_D2I_RSAPRIVATEKEY,0),	"D2i_RSAPrivateKey"},
{ERR_PACK(0,DER_F_D2I_RSAPUBLICKEY,0),	"D2i_RSAPublicKey"},
{ERR_PACK(0,DER_F_I2D_RSAPRIVATEKEY_FP,0),	"i2D_RSAPivateKey_fp"},
{ERR_PACK(0,DER_F_I2D_RSAPRIVATEKEY,0),	"i2D_RSAPivateKey"},
{ERR_PACK(0,DER_F_I2D_RSAPUBLICKEY,0),	"i2D_RSAPublicKey"},
{ERR_PACK(0,DER_F_F2I_X509_ALGOR,0),	"f2i_X509_ALGOR"},
{ERR_PACK(0,DER_F_F2I_X509_NAME,0),	"f2i_X509_NAME"},
{ERR_PACK(0,DER_F_F2I_X509_VAL,0),	"f2i_X509_VAL"},
{ERR_PACK(0,DER_F_F2I_X509_PUBKEY,0),	"f2i_X509_PUBKEY"},
{ERR_PACK(0,DER_F_F2I_X509_SIG,0),	"f2i_X509_SIG"},
{ERR_PACK(0,DER_F_F2I_X509_CINF,0),	"f2i_X509_CINF"},
{ERR_PACK(0,DER_F_F2I_X509_REVOKED,0),	"f2i_X509_REVOKED"},
{ERR_PACK(0,DER_F_F2I_X509_REVOKED_LIST,0),	"f2i_X509_REVOKED_list"},
{ERR_PACK(0,DER_F_F2I_X509_CRL_INFO,0),	"f2i_X509_CRL_INFO"},
{ERR_PACK(0,DER_F_F2I_X509_CRL,0),	"f2i_X509_CRL"},
{ERR_PACK(0,DER_F_F2I_X509,0),	"f2i_X509"},
{ERR_PACK(0,DER_F_F2I_PRINTABLESTRING,0),	"f2i_PRINTABLESTRING"},
{ERR_PACK(0,DER_F_F2I_DER_BIT_STRING,0),	"f2i_DER_BIT_STRING"},
{ERR_PACK(0,DER_F_F2I_DER_OBJECT,0),	"f2i_DER_OBJECT"},
{ERR_PACK(0,DER_F_F2I_RSAPRIVATEKEY,0),	"f2i_RSAPrivateKey"},
{ERR_PACK(0,DER_F_F2I_RSAPUBLICKEY,0),	"f2i_RSAPublicKey"},
{ERR_PACK(0,DER_F_I2D_X509_CRL_FP,0),	"i2D_X509_CRL_fp"},
{ERR_PACK(0,DER_F_I2D_X509_FP,0),	"i2D_X509_fp"},
{ERR_PACK(0,DER_F_I2F_RSAPRIVATEKEY,0),	"i2f_RSAPrivateKey"},
{ERR_PACK(0,DER_F_I2F_RSAPUBLICKEY,0),	"i2f_RSAPublicKey"},
{ERR_PACK(0,DER_F_DER_BIT_STRING_NEW,0),	"DER_BIT_STRING_new"},
{ERR_PACK(0,DER_F_DER_OBJECT_NEW,0),	"DER_OBJECT_new"},
{ERR_PACK(0,DER_F_D2I_INTEGER,0),	"D2i_INTEGER"},
{ERR_PACK(0,DER_F_D2I_DER_OBJECT,0),	"D2i_DER_OBJECT"},
{ERR_PACK(0,DER_F_D2I_PRINTABLESTRING,0),	"D2i_PRINTABLESTRING"},
{ERR_PACK(0,DER_F_D2I_DER_BIT_STRING,0),	"D2i_DER_BIT_STRING"},
{ERR_PACK(0,DER_F_D2I_DER_OCTET_STRING,0),	"D2I_DER_OCTET_STRING"},
{ERR_PACK(0,DER_F_D2I_UTCTIME,0),	"D2i_UTCTime"},
{ERR_PACK(0,DER_F_D2I_X509_REQ_INFO,0),	"D2i_X509_REQ_INFO"},
{ERR_PACK(0,DER_F_D2I_X509_REQ,0),	"D2i_X509_REQ"},
{ERR_PACK(0,DER_F_I2D_X509_REQ_INFO,0),	"i2D_X509_REQ_INFO"},
{ERR_PACK(0,DER_F_I2D_X509_REQ,0),	"i2D_X509_REQ"},
{ERR_PACK(0,DER_F_I2F_X509_REQ_INFO,0),	"i2f_X509_REQ_INFO"},
{ERR_PACK(0,DER_F_I2F_X509_REQ,0),	"i2f_X509_REQ"},
{ERR_PACK(0,DER_F_F2I_X509_REQ_INFO,0),	"f2i_X509_REQ_INFO"},
{ERR_PACK(0,DER_F_F2I_X509_REQ,0),	"f2i_X509_REQ"},
{ERR_PACK(0,DER_F_I2D_X509_REQ_FP,0),	"i2D_X509_REQ_fp"},
{ERR_PACK(0,DER_F_D2I_X509_REQ_FP,0),	"D2i_X509_REQ_fp"},
{0,NULL},
	};

static ERR_STRING_DATA DER_str_reasons[]=
	{
{DER_R_EXPECTING_A_SEQUENCE              ,"expecting a sequence"},
{DER_R_EXPECTING_A_NULL                  ,"expecting a null"},
{DER_R_EXPECTING_A_SET                   ,"expecting a set"},
{DER_R_EXPECTING_AN_INTEGER              ,"expecting an integer"},
{DER_R_EXPECTING_AN_OBJECT               ,"expecting an object"},
{DER_R_EXPECTING_A_PRINTABLESTRING       ,"expecting a printablestring"},
{DER_R_EXPECTING_A_BIT_STRING            ,"expecting a bit string"},
{DER_R_EXPECTING_AN_OCTET_STRING         ,"expecting an octet string"},
{DER_R_EXPECTING_AN_UTCTIME              ,"expecting an utctime"},
{DER_R_NOT_ENOUGH_DATA                   ,"not enough data"},
{DER_R_EXPECTING_A_BEGIN_TOKEN           ,"expecting a begin token"},
{DER_R_EXPECTING_A_END_TOKEN             ,"expecting a end token"},
{DER_R_SHORT_LINE                        ,"short line"},
{DER_R_BAD_SOL_CHARACTER                 ,"bad sol character"},
{DER_R_BAD_EOL_CHARACTER                 ,"bad eol character"},
{DER_R_ODD_NUMBER_OF_CHARS               ,"odd number of chars"},
{DER_R_NON_HEX_CHARACTERS                ,"non hex characters"},
{DER_R_LENGTH_MISMATCH                   ,"length mismatch"},
{DER_R_BAD_TAG                           ,"bad tag"},
{0,NULL},
	};


void ERR_load_DER_strings()
	{
	static int init=1;

	if (init)
		{
		ERR_load_strings(ERR_LIB_DER,DER_str_functs);
		ERR_load_strings(ERR_LIB_DER,DER_str_reasons);
		init=0;
		}
	}

