/* lib/x509/x509_obj.c */
/* Copyright (C) 1995 Eric Young (eay@mincom.oz.au)
 * All rights reserved.
 * 
 * This file is part of an SSL implementation written
 * by Eric Young (eay@mincom.oz.au).
 * The implementation was written so as to conform with Netscapes SSL
 * specification.  This library and applications are
 * FREE FOR COMMERCIAL AND NON-COMMERCIAL USE
 * as long as the following conditions are aheared to.
 * 
 * Copyright remains Eric Young's, and as such any Copyright notices in
 * the code are not to be removed.  If this code is used in a product,
 * Eric Young should be given attribution as the author of the parts used.
 * This can be in the form of a textual message at program startup or
 * in documentation (online or textual) provided with the package.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by Eric Young (eay@mincom.oz.au)
 * 
 * THIS SOFTWARE IS PROVIDED BY ERIC YOUNG ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * 
 * The licence and distribution terms for any publically available version or
 * derivative of this code cannot be changed.  i.e. this code cannot simply be
 * copied and put under another distribution licence
 * [including the GNU Public Licence.]
 */

#include <stdio.h>
#include "crypto.h"
#include "lhash.h"
#include "der.h"
#include "x509.h"
#include "x509_obj.h"
#include "buffer.h"

/* Perhaps I should have objects as strings?  bit late now :-( */

static struct obj_st 
	{
	char *sn,*ln;
	int nid;
	long nums[8];
	} objs[]={
	{NULL,LN_rsadsi,NID_rsadsi,{OBJ_rsadsi,0}},
	{NULL,LN_pkcs,NID_pkcs,{OBJ_pkcs,0}},
	{NULL,LN_md2,NID_md2,{OBJ_md2,0}},
	{NULL,LN_md5,NID_md5,{OBJ_md5,0}},
	{NULL,LN_rc4,NID_rc4,{OBJ_rc4,0}},
	{NULL,LN_rsaEncryption,NID_rsaEncryption,{OBJ_rsaEncryption,0}},
	{NULL,LN_md2withRSAEncryption,
		NID_md2withRSAEncryption,{OBJ_md2withRSAEncryption,0}},
	{NULL,LN_md5withRSAEncryption,
		NID_md5withRSAEncryption,{OBJ_md5withRSAEncryption,0}},
	{NULL,LN_pbeWithMD2AndDES_CBC,
		NID_pbeWithMD2AndDES_CBC,{OBJ_pbeWithMD2AndDES_CBC,0}},
	{NULL,LN_pbeWithMD5AndDES_CBC,
		NID_pbeWithMD5AndDES_CBC,{OBJ_pbeWithMD5AndDES_CBC,0}},
	{SN_commonName,LN_commonName,NID_commonName,{OBJ_commonName,0}},
	{SN_countryName,LN_countryName,NID_countryName,{OBJ_countryName,0}},
	{SN_localityName,LN_localityName,NID_localityName,{OBJ_localityName,0}},
	{SN_stateOrProcinceName,LN_stateOrProcinceName,
		NID_stateOrProcinceName,{OBJ_stateOrProcinceName,0}},
	{SN_organizationName,LN_organizationName,
		NID_organizationName,{OBJ_organizationName,0}},
	{SN_organizationalUnitName,LN_organizationalUnitName,
		NID_organizationalUnitName,{OBJ_organizationalUnitName,0}},
	{NULL,LN_rsa,NID_rsa,{OBJ_rsa,0}},
	{NULL,LN_X500,NID_X500,{OBJ_X500,0}},
	{NULL,LN_X509,NID_X509,{OBJ_X509,0}},
	{NULL,LN_pkcs7,NID_pkcs7,{OBJ_pkcs7,0}},
	{NULL,LN_pkcs7_data,NID_pkcs7_data,{OBJ_pkcs7_data,0}},
	{NULL,LN_pkcs7_signedData,NID_pkcs7_signedData,
		{OBJ_pkcs7_signedData,0}},
	{NULL,LN_pkcs7_envelopedData,NID_pkcs7_envelopedData,
		{OBJ_pkcs7_envelopedData,0}},
	{NULL,LN_pkcs7_signedAndEnvelopedData,NID_pkcs7_signedAndEnvelopedData,
		{OBJ_pkcs7_signedAndEnvelopedData,0}},
	{NULL,LN_pkcs7_digestData,NID_pkcs7_digestData,
		{OBJ_pkcs7_digestData,0}},
	{NULL,LN_pkcs7_encryptedData,NID_pkcs7_encryptedData,
		{OBJ_pkcs7_encryptedData,0}},
	{NULL,NULL,0,{0}}
	};

static LHASH *obj_h=NULL;
static LHASH *nid_h=NULL;
static LHASH *sn_h=NULL;
static LHASH *ln_h=NULL;
static int init=1;

#ifdef PROTO
static unsigned long nid_hash(DER_OBJECT * a);
static int nid_cmp(DER_OBJECT * a, DER_OBJECT * b);
static unsigned long obj_hash(DER_OBJECT * a);
static int obj_cmp(DER_OBJECT * a, DER_OBJECT * b);
static unsigned long sn_hash(DER_OBJECT * a);
static int sn_cmp(DER_OBJECT * a, DER_OBJECT * b);
static unsigned long ln_hash(DER_OBJECT * a);
static int ln_cmp(DER_OBJECT * a, DER_OBJECT * b);
static int init_obj(void);
#else
static unsigned long nid_hash();
static int nid_cmp();
static unsigned long obj_hash();
static int obj_cmp();
static unsigned long sn_hash();
static int sn_cmp();
static unsigned long ln_hash();
static int ln_cmp();
static int init_obj();
#endif

static unsigned long nid_hash(a)
DER_OBJECT *a;
	{ return(a->nid); }

static int nid_cmp(a,b)
DER_OBJECT *a;
DER_OBJECT *b;
	{ return(a->nid-b->nid); }

static unsigned long obj_hash(a)
DER_OBJECT *a;
	{
	unsigned long ret=1;
	int i;

	for (i=0; i<a->num; i++)
		ret*=(a->values[i]+1);
	return(ret);
	}

static int obj_cmp(a, b)
DER_OBJECT *a;
DER_OBJECT *b;
	{
	int i,j;

	i=a->num-b->num;
	if (i != 0) return(i);
	for (i=0; i<a->num; i++)
		{
		j=(int)a->values[i]-b->values[i];
		if (j != 0) return(j);
		}
	return(0);
	}

static unsigned long sn_hash(a)
DER_OBJECT *a;
	{ return(lh_strhash(a->sn)); }

static int sn_cmp(a,b)
DER_OBJECT *a;
DER_OBJECT *b;
	{ return(strcmp(a->sn,b->sn)); }

static unsigned long ln_hash(a)
DER_OBJECT *a;
	{ return(lh_strhash(a->ln)); }

static int ln_cmp(a,b)
DER_OBJECT *a;
DER_OBJECT *b;
	{ return(strcmp(a->ln,b->ln)); }

static int init_obj()
	{
	int i,j;
	DER_OBJECT *a,*b;

	if (obj_h == NULL) obj_h=lh_new(obj_hash,obj_cmp);
	if (nid_h == NULL) nid_h=lh_new(nid_hash,nid_cmp);
	if (sn_h == NULL) sn_h=lh_new(sn_hash,sn_cmp);
	if (ln_h == NULL) ln_h=lh_new(ln_hash,ln_cmp);
	if ((obj_h == NULL) || (nid_h == NULL) ||
		(sn_h == NULL) || (ln_h == NULL))
		{
		X509err(X509_F_INIT_OBJ,ERR_R_MALLOC_FAILURE);
		goto err;
		}

	for (i=0; objs[i].nid != 0; i++)
		{
		a=(DER_OBJECT *)DER_OBJECT_new();
		if (a == NULL) 
			{
			X509err(X509_F_INIT_OBJ,ERR_R_DER_LIB);
			goto err;
			}
		a->sn=objs[i].sn;
		a->ln=objs[i].ln;
		a->nid=objs[i].nid;
		for (j=0; objs[i].nums[j] != 0; j++);
		a->num=j;
		a->values=(unsigned long *)malloc(sizeof(unsigned long *)*j);
		if (a->values == NULL)
			{
			X509err(X509_F_INIT_OBJ,ERR_R_MALLOC_FAILURE);
			goto err;
			}
		for (j=0; objs[i].nums[j] != 0; j++)
			a->values[j]=objs[i].nums[j];

		b=(DER_OBJECT *)lh_insert(obj_h,(char *)a);
		if (b != NULL)
			{
			X509err(X509_F_INIT_OBJ,X509_R_HIT_IN_OBJECT_STORAGE);
			goto err;
			}
		b=(DER_OBJECT *)lh_insert(nid_h,(char *)a);
		if (b != NULL)
			{
			X509err(X509_F_INIT_OBJ,X509_R_HIT_IN_NID_STORAGE);
			goto err;
			}
		if (a->sn != NULL)
			{
			b=(DER_OBJECT *)lh_insert(sn_h,(char *)a);
			if (b != NULL)
				{
				X509err(X509_F_INIT_OBJ,
					X509_R_HIT_IN_SN_STORAGE);
				goto err;
				}
			}
		if (a->ln != NULL)
			{
			b=(DER_OBJECT *)lh_insert(ln_h,(char *)a);
			if (b != NULL)
				{
				X509err(X509_F_INIT_OBJ,
					X509_R_HIT_IN_LN_STORAGE);
				goto err;
				}
			}
		}
	init=0;
	return(1);
err:
	abort();
	return(0);
	}


DER_OBJECT *X509_nid2obj(n)
int n;
	{
	DER_OBJECT o;

	if (init && !init_obj()) return(NULL);

	o.nid=n;
	return((DER_OBJECT *)lh_retrieve(nid_h,(char *)&o));
	}

int X509_obj2nid(a)
DER_OBJECT *a;
	{
	DER_OBJECT *o;

	if (init && !init_obj()) return(0);
	o=(DER_OBJECT *)lh_retrieve(obj_h,(char *)a);
	if (o == NULL) return(NID_undef);
	return(o->nid);
	}

char *X509_nid2sn(n)
int n;
	{
	DER_OBJECT o,*oo;

	if (init && !init_obj()) return(NULL);
	o.nid=n;
	oo=(DER_OBJECT *)lh_retrieve(nid_h,(char *)&o);
	if (oo == NULL) return(NULL);
	return(oo->sn);
	}

char *X509_nid2ln(n)
int n;
	{
	DER_OBJECT o,*oo;

	if (init && !init_obj()) return(NULL);
	o.nid=n;
	oo=(DER_OBJECT *)lh_retrieve(nid_h,(char *)&o);
	if (oo == NULL) return(NULL);
	return(oo->ln);
	}

int X509_ln2nid(s)
char *s;
	{
	DER_OBJECT o,*oo;

	if (init && !init_obj()) return(0);
	o.ln=s;
	oo=(DER_OBJECT *)lh_retrieve(ln_h,(char *)&o);
	if (oo == NULL) return(0);
	return(oo->nid);
	}

int X509_sn2nid(s)
char *s;
	{
	DER_OBJECT o,*oo;

	if (init && !init_obj()) return(0);
	o.sn=s;
	oo=(DER_OBJECT *)lh_retrieve(sn_h,(char *)&o);
	if (oo == NULL) return(0);
	return(oo->nid);
	}

DER_OBJECT *X509_dup_DER_OBJECT(o)
DER_OBJECT *o;
	{
	DER_OBJECT *r;
	int i;

	if (o == NULL) return(NULL);
	r=(DER_OBJECT *)DER_OBJECT_new();
	if (r == NULL)
		{
		X509err(X509_F_X509_DUP_DER_OBJECT,ERR_R_DER_LIB);
		return(NULL);
		}
	r->values=(unsigned long *)malloc(sizeof(unsigned long)*o->num);
	if (r->values == NULL)
		{
		X509err(X509_F_X509_DUP_DER_OBJECT,ERR_R_MALLOC_FAILURE);
		return(NULL);
		}
	for (i=0; i<o->num; i++)
		r->values[i]=o->values[i];
	r->num=o->num;
	r->nid=o->nid;
	r->ln=o->ln;
	r->sn=o->sn;
	return(r);
	}

char *X509_oneline_X509_NAME(a)
X509_NAME *a;
	{
	int i,n,o=0,l=1,l1,l2;
	char *s;
	BUFFER *b;

	if (a == NULL) return("NO X509_NAME");
	o=0;
	b=buffer_new();
	if (b == NULL)
		{
		X509err(X509_F_X509_ONELINE_X509_NAME,ERR_R_MALLOC_FAILURE);
		return(NULL);
		}
	for (i=0; i<a->num; i++)
		{
		n=X509_obj2nid(a->objects[i]);
		if (n == NID_undef)
			s="UNKNOWN";
		else
			{
			s=X509_nid2sn(n);
			if (s == NULL) s="UNKNOWN2";
			}
		l1=strlen(s);
		l2=a->values[i]->length;
		l+=1+l1+1+l2;
		if (!buffer_grow(b,(long)l))
			{
			X509err(X509_F_X509_ONELINE_X509_NAME,
				ERR_R_MALLOC_FAILURE);
			return(NULL);
			}
		memcpy(&(b->data[o]),"/",1); o++;
		memcpy(&(b->data[o]),s,(unsigned int)l1); o+=l1;
		memcpy(&(b->data[o]),"=",1); o++;
		memcpy(&(b->data[o]),a->values[i]->data,(unsigned int)l2+1);
		o+=l2;
		}
	s=b->data;
	free(b);
	return(s);
	}
