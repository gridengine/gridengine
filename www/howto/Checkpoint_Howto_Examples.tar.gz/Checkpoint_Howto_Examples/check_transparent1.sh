#!/bin/sh
# check_transparent1.sh

trap 'date >> $SGE_CKPT_DIR/checkpoint_1' usr2

echo "Script started."

for ((i=0; i<1000; i++)) ; do
    sleep 1
done

echo "Script finished."

exit 0
