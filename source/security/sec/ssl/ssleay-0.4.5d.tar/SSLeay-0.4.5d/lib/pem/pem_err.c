/* lib/pem/pem_err.c */
/* Copyright (C) 1995 Eric Young (eay@mincom.oz.au)
 * All rights reserved.
 * 
 * This file is part of an SSL implementation written
 * by Eric Young (eay@mincom.oz.au).
 * The implementation was written so as to conform with Netscapes SSL
 * specification.  This library and applications are
 * FREE FOR COMMERCIAL AND NON-COMMERCIAL USE
 * as long as the following conditions are aheared to.
 * 
 * Copyright remains Eric Young's, and as such any Copyright notices in
 * the code are not to be removed.  If this code is used in a product,
 * Eric Young should be given attribution as the author of the parts used.
 * This can be in the form of a textual message at program startup or
 * in documentation (online or textual) provided with the package.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by Eric Young (eay@mincom.oz.au)
 * 
 * THIS SOFTWARE IS PROVIDED BY ERIC YOUNG ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * 
 * The licence and distribution terms for any publically available version or
 * derivative of this code cannot be changed.  i.e. this code cannot simply be
 * copied and put under another distribution licence
 * [including the GNU Public Licence.]
 */

#include <stdio.h>
#include "crypto.h"
#include "x509.h"

static ERR_STRING_DATA PEM_str_functs[]=
	{
{ERR_PACK(0,PEM_F_PEM_WRITE_X509,0),	"PEM_write_X509"},
{ERR_PACK(0,PEM_F_PEM_READ_X509,0),	"PEM_read_X509"},
{ERR_PACK(0,PEM_F_PEM_WRITE_CRL,0),	"PEM_WRITE_CRL"},
{ERR_PACK(0,PEM_F_PEM_READ_CRL,0),	"PEM_READ_CRL"},
{ERR_PACK(0,PEM_F_PEM_READ_RSA,0),	"PEM_read_RSA"},
{ERR_PACK(0,PEM_F_PEM_WRITE_RSA,0),	"PEM_write_RSA"},
{ERR_PACK(0,PEM_F_PEM_DO_HEADER,0),	"PEM_do_header"},
{ERR_PACK(0,PEM_F_GET_KEY_BYTES,0),	"GET_KEY_BYTES"},
{ERR_PACK(0,PEM_F_LOAD_IV,0),	"LOAD_IV"},
{ERR_PACK(0,PEM_F_PEM_ASCII2BIN,0),	"PEM_ascii2bin"},
{ERR_PACK(0,PEM_F_PEM_READ,0),	"PEM_read"},
{ERR_PACK(0,PEM_F_PEM_WRITE,0),	"PEM_write"},
{ERR_PACK(0,PEM_F_PEM_DES_CBC_ENCRYPT,0),	"PEM_DES_CBC_ENCRYPT"},
{ERR_PACK(0,PEM_F_PEM_DES_EDE2_ENCRYPT,0),	"PEM_DES_EDE2_ENCRYPT"},
{ERR_PACK(0,PEM_F_PEM_IDEA_CBC_ENCRYPT,0),	"PEM_IDEA_CBC_ENCRYPT"},
{ERR_PACK(0,PEM_F_PEM_WRITE_X509_REQ,0),	"PEM_write_X509_REQ"},
{ERR_PACK(0,PEM_F_DEF_CALLBACK,0),	"DEF_CALLBACK"},
{ERR_PACK(0,PEM_F_PEM_DIGESTINIT,0),	"PEM_DigestInit"},
{ERR_PACK(0,PEM_F_PEM_DIGESTUPDATE,0),	"PEM_DigestUpdate"},
{ERR_PACK(0,PEM_F_PEM_DIGESTFINAL,0),	"PEM_DigestFinal"},
{ERR_PACK(0,PEM_F_PEM_SIGNFINAL,0),	"PEM_SignFinal"},
{ERR_PACK(0,PEM_F_PEM_VERIFYFINAL,0),	"PEM_VerifyFinal"},
{ERR_PACK(0,PEM_F_PEM_SEALINIT,0),	"PEM_SEALINIT"},
{ERR_PACK(0,PEM_F_PEM_SEALUPDATE,0),	"PEM_SEALUPDATE"},
{ERR_PACK(0,PEM_F_INIT_CIPHER,0),	"INIT_CIPHER"},
{ERR_PACK(0,PEM_F_DO_CIPHER,0),	"DO_CIPHER"},
{ERR_PACK(0,PEM_F_PEM_OPENINIT,0),	"PEM_OPENINIT"},
{ERR_PACK(0,PEM_F_PEM_OPENFINAL,0),	"PEM_OPENFINAL"},
{ERR_PACK(0,PEM_F_PEM_READ_X509_REQ,0),	"PEM_read_X509_REQ"},
{0,NULL},
	};

static ERR_STRING_DATA PEM_str_reasons[]=
	{
{PEM_R_READ_KEY                          ,"read key"},
{PEM_R_NOT_PROC_TYPE                     ,"not proc type"},
{PEM_R_NOT_ENCRYPTED                     ,"not encrypted"},
{PEM_R_SHORT_HEADER                      ,"short header"},
{PEM_R_NOT_DEK_INFO                      ,"not dek info"},
{PEM_R_UNSUPPORTED_ENCRYPTION            ,"unsupported encryption"},
{PEM_R_BAD_READ_PW_STRING                ,"bad read pw string"},
{PEM_R_BASE64_BAD_INPUT_CHAR             ,"base64 bad input char"},
{PEM_R_BASE64_LINE_TOO_LONG              ,"base64 line too long"},
{PEM_R_NO_START_LINE                     ,"no start line"},
{PEM_R_BAD_END_LINE                      ,"bad end line"},
{PEM_R_BAD_DECRYPT                       ,"bad decrypt"},
{PEM_R_BAD_IV_CHARS                      ,"bad iv chars"},
{PEM_R_BAD_MD_TYPE                       ,"bad md type"},
{PEM_R_DIGEST_DATA_TOO_BIG_FOR_KEY       ,"digest data too big for key"},
{PEM_R_BAD_SIGNATURE                     ,"bad signature"},
{PEM_R_BAD_CIPHER_TYPE                   ,"bad cipher type"},
{PEM_R_DATA_SIZE_NO_EQ_RSA_SIZE          ,"data size no eq rsa size"},
{PEM_R_WRONG_SIG_LENGTH                  ,"wrong sig length"},
{PEM_R_ALGORITHM_MISMATCH                ,"algorithm mismatch"},
{0,NULL},
	};

void ERR_load_PEM_strings()
	{
	static int init=1;

	if (init)
		{
		ERR_load_strings(ERR_LIB_PEM,PEM_str_functs);
		ERR_load_strings(ERR_LIB_PEM,PEM_str_reasons);
		init=0;
		}
	}

