/******************************************
*                                         *
* Demonstration program for checkpointing *
*            condor_program6.c            *
*                                         *
******************************************/

#include <math.h>

struct checkpoint_struct {

    short    position;
    float    values[1000];
} computing;

/***************************
*                          *
* Main program starts here *
*                          *
***************************/

int main(int argc, char **argv)
{
    int         i;

    long        mytimer;

/************************
*                       *
* Now start the program *
*                       *
************************/

    computing.position=0;

    for ( ; computing.position < 1000; computing.position++)
    {
        computing.values[computing.position] = sqrt(computing.position);
        mytimer=time();
        while (mytimer == time())
            ;
    }

/*********************
*                    *
* Output the results *
*                    *
*********************/

    for (i=0; i < 1000; i++)
        printf("sqrt(%d) = %f\n", i, computing.values[i]);

/*********************
*                    *
* End of the program *
*                    *
*********************/

    return(0);
}
