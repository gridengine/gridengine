#!/bin/sh

cwd=`pwd`

if test -s /bin/ranlib; then 
	cd /tmp && /bin/ranlib $cwd/$1
else if test -s /usr/bin/ranlib; then
	cd /tmp && /usr/bin/ranlib $cwd/$1
fi
fi
