/* apps/ssleay.c */
/* Copyright (C) 1995 Eric Young (eay@mincom.oz.au)
 * All rights reserved.
 * 
 * This file is part of an SSL implementation written
 * by Eric Young (eay@mincom.oz.au).
 * The implementation was written so as to conform with Netscapes SSL
 * specification.  This library and applications are
 * FREE FOR COMMERCIAL AND NON-COMMERCIAL USE
 * as long as the following conditions are aheared to.
 * 
 * Copyright remains Eric Young's, and as such any Copyright notices in
 * the code are not to be removed.  If this code is used in a product,
 * Eric Young should be given attribution as the author of the parts used.
 * This can be in the form of a textual message at program startup or
 * in documentation (online or textual) provided with the package.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by Eric Young (eay@mincom.oz.au)
 * 
 * THIS SOFTWARE IS PROVIDED BY ERIC YOUNG ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * 
 * The licence and distribution terms for any publically available version or
 * derivative of this code cannot be changed.  i.e. this code cannot simply be
 * copied and put under another distribution licence
 * [including the GNU Public Licence.]
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "x509.h"
#include "pem.h"
#include "ssl.h"
#include "s_apps.h"
#include "s_net.h"
#include "apps.h"

#undef DEBUG

#ifdef PROTO
static int chopup(char *buf, int *argc, char **argv[]);
#else
static int chopup();
#endif

#ifdef _Windows
#include "conio.h"

int getkey(buf,num,verify)
char *buf;
int num;
int verify;
	{
	fputs("Enter PEM pass phrase:",stdout);
	fflush(stdout);
	gets(buf);
	printf("<%s>\n",buf);
	return(strlen(buf));
	}

int app_fwrite(buf,size,num,fp)
char *buf;
int size;
int num;
FILE *fp;
	{
	return(fwrite(buf,size,num,fp));
	}

int app_fread(buf,size,num,fp)
char *buf;
int size;
int num;
FILE *fp;
	{
	return(fread(buf,size,num,fp));
	}

char *app_fgets(s,n,fp)
char *s;
int n;
FILE *fp;
	{
	return(fgets(s,n,fp));
	}
#endif
	
int main(Argc,Argv)
int Argc;
char *Argv[];
	{
	static char *prompt,buf[1024];
	int n,i;
	int argc;
	char **argv,*p;
	int ret;
 
#ifdef _Windows
	PEM_set_getkey_callback(getkey);
	WIN_init(app_fread,app_fwrite,app_fgets);
#endif

	for (;;)
		{
		ret=0;
		p=buf;
		n=1024;
		i=0;
		for (;;)
			{
			p[0]='\0';
			if (i++)
				prompt=">";
			else	prompt="SSLeay>";
			fputs(prompt,stdout);
			fflush(stdout);
			fgets(p,n,stdin);
			if (p[0] == '\0')
				{
				EXIT(0);
				}
			i=strlen(p);
			if (i <= 1) break;
			if (p[i-2] != '\\') break;
			i-=2;
			p+=i;
			n-=i;
			}
		if (!chopup(buf,&argc,&argv)) break;

#ifdef DEBUG
		for (i=0; i<argc; i++)
			printf("%2d:<%s>\n",i,argv[i]);
#endif

		if 	(strcmp(argv[0],"crl") == 0)
			ret=crl_main(argc,argv);
		else if (strcmp(argv[0],"derparse") == 0)
			ret=derparse_main(argc,argv);
		else if (strcmp(argv[0],"genrsa") == 0)
			ret=genrsa_main(argc,argv);
		else if (strcmp(argv[0],"pem2der") == 0)
			ret=pem2der_main(argc,argv);
		else if (strcmp(argv[0],"rsa") == 0)
			ret=rsa_main(argc,argv);
		else if (strcmp(argv[0],"s_client") == 0)
			ret=s_client_main(argc,argv);
		else if (strcmp(argv[0],"s_server") == 0)
			ret=s_server_main(argc,argv);
#ifndef MSDOS
		else if (strcmp(argv[0],"s_filter") == 0)
			ret=s_filter_main(argc,argv);

#endif
		else if (strcmp(argv[0],"speed") == 0)
			ret=speed_main(argc,argv);
		else if (strcmp(argv[0],"verify") == 0)
			ret=verify_main(argc,argv);
		else if (strcmp(argv[0],"x509") == 0)
			ret=x509_main(argc,argv);
		else if (strcmp(argv[0],"req") == 0)
			ret=req_main(argc,argv);

		else if ((strcmp(argv[0],"quit") == 0) ||
			(strcmp(argv[0],"exit") == 0) ||
			(strcmp(argv[0],"bye") == 0))
			{ EXIT(0); }
		else
			{
			fprintf(stderr,"bad command, valid commands are\n");
			fprintf(stderr,"crt      rsa      x509    verify\n");
			fprintf(stderr,"derparse pem2der  speed   genrsa\n");
			fprintf(stderr,"req\n");
			fprintf(stderr,"s_client s_server s_filter\n");
			fprintf(stderr,"quit\n");
			ret=0;
			}
		if (ret != 0)
			{
			fprintf(stderr,"error in %s module\n",argv[0]);
			}
		}
	fprintf(stderr,"bad exit\n");
	EXIT(1);
	}

static int chopup(buf,argc,argv)
char *buf;
int *argc;
char **argv[];
	{
	int num,len,i;
	static char **arg=NULL;
	static int argcount=0;
	char *p;

	*argc=0;
	*argv=NULL;

	len=strlen(buf);
	i=0;
	if (argcount == 0)
		{
		argcount=20;
		arg=(char **)malloc(sizeof(char *)*argcount);
		}

	num=0;
	p=buf;
	for (;;)
		{
		/* first scan over white space */
		if (!*p) break;
		while (*p && ((*p == ' ') || (*p == '\t') || (*p == '\n')))
			p++;
		if (!*p) break;

		/* The start of something good :-) */
		if (num >= argcount)
			{
			argcount+=20;
			arg=(char **)realloc(arg,sizeof(char *)*argcount);
			if (argc == 0) return(0);
			}
		arg[num++]=p;

		/* now look for the end of this */
		if ((*p == '\'') || (*p == '\"')) /* scan for closing quote */
			{
			i= *(p++);
			arg[num-1]++; /* jump over quote */
			while (*p && (*p != i))
				p++;
			*p='\0';
			}
		else
			{
			while (*p && ((*p != ' ') &&
				(*p != '\t') && (*p != '\n')))
				p++;

			*p='\0';
			}
		p++;
		}
	*argc=num;
	*argv=arg;
	return(1);
	}
