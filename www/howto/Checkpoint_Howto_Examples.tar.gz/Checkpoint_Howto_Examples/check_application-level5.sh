#!/bin/sh
# check_application-level5.sh

SGE_CKPT_JOB=$SGE_CKPT_DIR/$JOB_ID

#
# Check whether we are restarted.
#

SGE_CKPT_FILE=$SGE_CKPT_JOB/checkpoint

if [ "$RESTARTED" -eq "2" -a -e "$SGE_CKPT_FILE" -a -r "$SGE_CKPT_FILE" ] ; then
    /home/reuti/checkpoint_program5 -r $SGE_CKPT_FILE -d $TMPDIR
else
    /home/reuti/checkpoint_program5 -d $TMPDIR
fi

exit 0
