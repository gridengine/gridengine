#!/usr/local/bin/perl

$fuction{'FOPEN'}='fopen';
while (<>)
	{
	if (/(\S+)\s*\(\);/)
		{
		$t=$1;
		$t =~ s/\*//;
		($upper=$t) =~ tr/a-z/A-Z/;
		$fuction{$upper}=$t;
		}
	next unless (/^#define\s+(\S+)\s/);

	$o=$1;
	if ($o =~ /^([^_]+)_F_(.*)/)
		{
		$n=$2;
		$n=$fuction{$n} if (defined($fuction{$n}));
		$out{$1."_str_functs"}.=
			sprintf("{ERR_PACK(0,%s,0),\t\"$n\"},\n",$o);
		}
	elsif ($o =~ /^([^_]+)_R_(.*)/)
		{
		$r=$2;
		$r =~ tr/A-Z_/a-z /;
		$out{$1."_str_reasons"}.=sprintf("{%-40s,\"$r\"},\n",$o);
		}
	}

foreach (sort keys %out)
	{
	print "static ERR_STRING_DATA ${_}[]=\n\t{\n";
	print $out{$_};
	print "{0,NULL},\n";
	print "\t};\n\n";
	}



