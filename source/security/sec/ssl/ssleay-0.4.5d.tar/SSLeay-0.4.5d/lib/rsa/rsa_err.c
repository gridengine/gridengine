/* lib/rsa/rsa_err.c */
/* Copyright (C) 1995 Eric Young (eay@mincom.oz.au)
 * All rights reserved.
 * 
 * This file is part of an SSL implementation written
 * by Eric Young (eay@mincom.oz.au).
 * The implementation was written so as to conform with Netscapes SSL
 * specification.  This library and applications are
 * FREE FOR COMMERCIAL AND NON-COMMERCIAL USE
 * as long as the following conditions are aheared to.
 * 
 * Copyright remains Eric Young's, and as such any Copyright notices in
 * the code are not to be removed.  If this code is used in a product,
 * Eric Young should be given attribution as the author of the parts used.
 * This can be in the form of a textual message at program startup or
 * in documentation (online or textual) provided with the package.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by Eric Young (eay@mincom.oz.au)
 * 
 * THIS SOFTWARE IS PROVIDED BY ERIC YOUNG ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * 
 * The licence and distribution terms for any publically available version or
 * derivative of this code cannot be changed.  i.e. this code cannot simply be
 * copied and put under another distribution licence
 * [including the GNU Public Licence.]
 */

#include <stdio.h>
#include "crypto.h"
#include "x509.h"

static ERR_STRING_DATA RSA_str_functs[]=
	{
{ERR_PACK(0,RSA_F_RSAREF_BN2BIN,0),	"RSAREF_BN2BIN"},
{ERR_PACK(0,RSA_F_RSA_PUBLIC_ENCRYPT,0),	"RSA_public_encrypt"},
{ERR_PACK(0,RSA_F_RSA_PRIVATE_ENCRYPT,0),	"RSA_private_encrypt"},
{ERR_PACK(0,RSA_F_RSA_PUBLIC_DECRYPT,0),	"RSA_public_decrypt"},
{ERR_PACK(0,RSA_F_RSA_PRIVATE_DECRYPT,0),	"RSA_private_decrypt"},
{ERR_PACK(0,RSA_F_RSA_BN_RAND,0),	"RSA_bn_rand"},
{ERR_PACK(0,RSA_F_RSA_NEW,0),	"RSA_new"},
{ERR_PACK(0,RSA_F_BN_NEW,0),	"bn_new"},
{ERR_PACK(0,RSA_F_BN_EXPAND,0),	"bn_expand"},
{ERR_PACK(0,RSA_F_BN_DIV,0),	"bn_div"},
{ERR_PACK(0,RSA_F_BN_MODMUL_RECIP,0),	"bn_modmul_recip"},
{ERR_PACK(0,RSA_F_BN_GET_REG,0),	"bn_get_reg"},
{ERR_PACK(0,RSA_F_BN_INVERSE_MODN,0),	"BN_INVERSE_MODN"},
{ERR_PACK(0,RSA_F_RSA_SIGN,0),	"RSA_sign"},
{ERR_PACK(0,RSA_F_RSA_GENERATE_KEY,0),	"RSA_generate_key"},
{0,NULL},
	};

static ERR_STRING_DATA RSA_str_reasons[]=
	{
{RSA_R_DATA_TO_LARGE                     ,"data to large"},
{RSA_R_DATA_NOT_EQ_TO_MOD_LEN            ,"data not eq to mod len"},
{RSA_R_BLOCK_TYPE_IS_NOT_01              ,"block type is not 01"},
{RSA_R_BLOCK_TYPE_IS_NOT_02              ,"block type is not 02"},
{RSA_R_NULL_BEFORE_BLOCK_MISSING         ,"null before block missing"},
{RSA_R_BAD_PAD_BYTE_COUNT                ,"bad pad byte count"},
{RSA_R_BAD_FF_HEADER                     ,"bad ff header"},
{RSA_R_BAD_SIG_TYPE                      ,"bad sig type"},
{RSA_R_DIGEST_KEY_TOO_BIG_FOR_KEY        ,"digest key too big for key"},
{RSA_R_RSA_PRIVATE_ENCRYPT               ,"rsa private encrypt"},
{RSA_R_BAD_E_VALUE                       ,"bad e value"},
{RSA_R_NULL_ARG                          ,"null arg"},
{RSA_R_DIV_BY_ZERO                       ,"div by zero"},
{RSA_R_BAD_BN_MODMUL_RECIP               ,"bad bn modmul recip"},
{RSA_R_INVERSE_MODN_NO_SOLUTION          ,"inverse modn no solution"},
{0,NULL},
	};

void ERR_load_RSA_strings()
	{
	static int init=1;

	if (init)
		{
		ERR_load_strings(ERR_LIB_RSA,RSA_str_functs);
		ERR_load_strings(ERR_LIB_RSA,RSA_str_reasons);
		init=0;
		}
	}

