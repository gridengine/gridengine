/******************************************
*                                         *
* Demonstration program for checkpointing *
*        checkpoint_program4.c            *
*                                         *
******************************************/

#include <stdio.h>
#include <unistd.h>
#include <sys/stat.h>
#include <math.h>

#define TRUE 1
#define FALSE 0

static char        checkpoint_directory[255];
static char        checkpoint_name[]="/checkpoint_5";
static char        checkpoint_last[]="/checkpoint_5.old";

static int         just_started=TRUE;

struct checkpoint_struct {

    short    position;
    float    values[1000];
} computing;

/********************************
*                               *
* Initialization of the program *
*                               *
********************************/

void init_program(struct checkpoint_struct *value)
{
    value->position=0;
}

/*******************************
*                              *
* Here we write the checkpoint *
*                              *
*******************************/

void checkpoint_creation()
{
    char    checkpoint_old[255];
    char    checkpoint_new[255];

    struct stat sbuf;

    FILE    *checkpoint_file;

    fprintf(stderr, "Checkpoint creation initiated.\n");

    strcpy(checkpoint_old, checkpoint_directory);
    strcat(checkpoint_old, checkpoint_last);
    strcpy(checkpoint_new, checkpoint_directory);
    strcat(checkpoint_new, checkpoint_name);

    if (stat(checkpoint_new, &sbuf) == 0)
        if (link(checkpoint_new, checkpoint_old) != 0)
            fprintf(stderr, "Couldn't rename old checkpoint file.\n");
        else if (unlink(checkpoint_new) != 0)
            fprintf(stderr, "Couldn't unlink old checkpoint file.\n");

    checkpoint_file=fopen(checkpoint_new, "wb");

    if (checkpoint_file == NULL)
        fprintf(stderr, "Couldn't open checkpoint file for writing.\n");
    else if (fwrite(&computing, sizeof computing, 1, checkpoint_file) != 1) 
        fprintf(stderr, "Couldn't write checkpoint file.\n");
    else if (fclose(checkpoint_file) != 0)
        fprintf(stderr, "Couldn't close checkpoint file.\n");
    else 
        fprintf(stderr, "Checkpoint file created to restart with %d.\n", computing.position);

    if (stat(checkpoint_old, &sbuf) == 0)
        if (unlink(checkpoint_old) != 0)
            fprintf(stderr, "Couldn't remove old checkpoint file.\n");
}

/***************************
*                          *
* Main program starts here *
*                          *
***************************/

int main(int argc, char **argv)
{
    int         option;
    static char option_string[]=":d:r:";
    int         checkpoint_enabled=FALSE;
    int         restarted=FALSE;

    int         i;

    struct stat sbuf;

    char        checkpoint_read[255];

    FILE        *checkpoint_file;

/********************************
*                               *
* Process the command line args *
*                               *
********************************/

    while ((option = getopt(argc, argv, option_string)) != -1)
        switch (option)
        {
            case 'r':
                strcpy(checkpoint_read, optarg);
                if (stat(checkpoint_read, &sbuf) != 0)
                {
                    fprintf(stderr, "Couldn't stat %s.\n", checkpoint_read);
                    abort();
                }
                if (S_ISREG(sbuf.st_mode))
                    restarted=TRUE;
                break;
            case 'd':
                strcpy(checkpoint_directory, optarg);
                if (stat(checkpoint_directory, &sbuf) != 0)
                {
                    fprintf(stderr, "Couldn't stat %s.\n", checkpoint_directory);
                    abort();
                }
                if (S_ISDIR(sbuf.st_mode))
                    checkpoint_enabled=TRUE;
                break;
            default:
                fprintf(stderr, "Unknown option: %s.\n", argv[optind-1]);
                abort();
        }              

/**********************************
*                                 *
* Access the last checkpoint file *
*                                 *
**********************************/

    if (restarted)
    {
        fprintf(stderr, "I will try to restart...\n");

        checkpoint_file=fopen(checkpoint_read, "rb");
        if (checkpoint_file == NULL)
        {
            fprintf(stderr,"Couldn't open checkpoint file for reading.\n");
            abort();
        }
        else if (fread(&computing, sizeof computing, 1, checkpoint_file) != 1)
        {
            fprintf(stderr,"Couldn't read checkpoint file.\n");
            abort();
        }
        else if (fclose(checkpoint_file) != 0)
        {
            fprintf(stderr,"Couldn't close checkpoint file.\n");
            abort();
        }
        else
            fprintf(stderr, "Checkpoint file read. Recalculation starts at %d.\n", computing.position);
    }
    else
        init_program(&computing);

/************************
*                       *
* Now start the program *
*                       *
************************/

    for ( ; computing.position < 1000; computing.position++)
    {
        computing.values[computing.position] = sqrt(computing.position);
        sleep(1);
        if (checkpoint_enabled && ! just_started)
            if (computing.position % 5 == 0)
                checkpoint_creation();
        just_started=FALSE;
    }

/*********************
*                    *
* Output the results *
*                    *
*********************/

    for (i=0; i < 1000; i++)
        printf("sqrt(%d) = %f\n", i, computing.values[i]);

/*********************
*                    *
* End of the program *
*                    *
*********************/

    return(0);
}
