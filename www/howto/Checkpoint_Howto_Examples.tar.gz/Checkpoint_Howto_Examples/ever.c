int main(void)
{
    float x;
    long  i;

    for (;;)
    {
        for (i=0;i<=100000;i++)
            x=3.1415926*i+i+i*i*2.7182818;
    }

    return 0;
}
