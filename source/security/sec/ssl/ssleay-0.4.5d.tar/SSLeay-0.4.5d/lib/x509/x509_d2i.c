/* lib/x509/x509_d2i.c */
/* Copyright (C) 1995 Eric Young (eay@mincom.oz.au)
 * All rights reserved.
 * 
 * This file is part of an SSL implementation written
 * by Eric Young (eay@mincom.oz.au).
 * The implementation was written so as to conform with Netscapes SSL
 * specification.  This library and applications are
 * FREE FOR COMMERCIAL AND NON-COMMERCIAL USE
 * as long as the following conditions are aheared to.
 * 
 * Copyright remains Eric Young's, and as such any Copyright notices in
 * the code are not to be removed.  If this code is used in a product,
 * Eric Young should be given attribution as the author of the parts used.
 * This can be in the form of a textual message at program startup or
 * in documentation (online or textual) provided with the package.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by Eric Young (eay@mincom.oz.au)
 * 
 * THIS SOFTWARE IS PROVIDED BY ERIC YOUNG ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * 
 * The licence and distribution terms for any publically available version or
 * derivative of this code cannot be changed.  i.e. this code cannot simply be
 * copied and put under another distribution licence
 * [including the GNU Public Licence.]
 */

#include <stdio.h>
#include "crypto.h"
#include "buffer.h"
#include "der.h"
#include "bn.h"
#include "x509.h"

#define READ_CHUNK	2048

#ifdef PROTO
static int D2i_X509_REVOKED_list(X509_CRL_INFO *a, unsigned char **pp);
#else
static int D2i_X509_REVOKED_list();
#endif

int D2i_X509_ALGOR(a, pp)
X509_ALGOR *a;
unsigned char **pp;
	{
	unsigned char *p,*s;
	unsigned long len;
	int i,tag,class;

	p= *pp;
	DER_get_object(&p,&len,&tag,&class);
	if (tag != DER_SEQUENCE)
		{
		DERerr(DER_F_D2I_X509_ALGOR,DER_R_EXPECTING_A_SEQUENCE);
		return(0);
		}

	i=D2i_DER_OBJECT(a->algorithm,&p);
	if (!i) return(0);

	DER_get_object(&p,&len,&tag,&class);
	a->type=tag;
	a->parameters->length=len;
	if (len > 0)
		{
		s=(unsigned char *)malloc(len);
		if (s == NULL)
			{
			DERerr(DER_F_D2I_X509_ALGOR,ERR_R_MALLOC_FAILURE);
			return(0);
			}
		memcpy(s,p,len);
		p+=len;
		a->parameters->data=s;
		}
	*pp=p;
	return(1);
	}

int D2i_X509_NAME(a, pp)
X509_NAME *a;
unsigned char **pp;
	{
	unsigned char *p,*pt,*ps,*p2;
	unsigned long len;
	int set,i,num_obj,tag,class;
	DER_BIT_STRING *bs;
#if defined(DG_GCC_BUG) && !defined(LINT)
	unsigned char *bug;
#endif

	p= *pp;
	DER_get_object(&p,&len,&tag,&class);
	if (tag != DER_SEQUENCE)
		{
		DERerr(DER_F_D2I_X509_NAME,DER_R_EXPECTING_A_SEQUENCE);
		return(0);
		}
	ps=p;
	pt=p+len;
	num_obj=0;
	while (p < pt)
		{
		DER_get_object(&p,&len,&tag,&class);
		if (tag != DER_SET)
			{
			DERerr(DER_F_D2I_X509_NAME,DER_R_EXPECTING_A_SET);
			return(0);
			}
		p2=p+len;
		while (p < p2)
			{
			DER_get_object(&p,&len,&tag,&class);
			if (tag != DER_SEQUENCE)
				{
				DERerr(DER_F_D2I_X509_NAME,
					DER_R_EXPECTING_A_SEQUENCE);
				return(0);
				}
			num_obj++;
			p+=len;
			}
		if (p != p2)
			{
			DERerr(DER_F_D2I_X509_NAME,DER_R_LENGTH_MISMATCH);
			return(0);
			}
		}
	if (a->num != 0)
		{
		for (i=0; i<a->num; i++)
			{
			if (a->objects[i] != NULL)
				DER_OBJECT_free(a->objects[i]);
			if (a->values[i] != NULL) 
				DER_BIT_STRING_free(a->values[i]);
			}
		free(a->objects);
		free(a->types);
		free(a->values);
		a->objects=NULL;
		a->types=NULL;
		a->values=NULL;
		a->num=0;
		}

	a->num=num_obj;
	a->objects=(DER_OBJECT **)malloc(sizeof(DER_OBJECT *)*num_obj);
	a->types=(int *)malloc(sizeof(int)*num_obj);
	a->values=(DER_BIT_STRING **)malloc(sizeof(DER_BIT_STRING *)*num_obj);
	if ((a->objects == NULL) || (a->values == NULL) || (a->types == NULL))
		{
		DERerr(DER_F_D2I_X509_NAME,ERR_R_MALLOC_FAILURE);
		return(0);
		}
	for (i=0; i<num_obj; i++)
		{
		a->objects[i]=NULL;
		a->types[i]=0;
		a->values[i]=NULL;
		}
	set=0;
	p=ps;
	num_obj=0;
	while (p < pt)
		{
		DER_get_object(&p,&len,&tag,&class);
		if (tag != DER_SET) /* test not needed */
			{
			DERerr(DER_F_D2I_X509_NAME,DER_R_EXPECTING_A_SET);
			return(0);
			}
		set++;	
		p2=p+len;
		while (p < p2)
			{
			DER_get_object(&p,&len,&tag,&class);
			if (tag != DER_SEQUENCE)
				{
				DERerr(DER_F_D2I_X509_NAME,
					DER_R_EXPECTING_A_SEQUENCE);
				return(0);
				}

			a->objects[num_obj]=(DER_OBJECT *)DER_OBJECT_new();
			if (a->objects[num_obj] == NULL) return(0);
			if (!D2i_DER_OBJECT(a->objects[num_obj],&p)) return(0);

			DER_get_object(&p,&len,&tag,&class);
			a->types[num_obj]=tag|(set<<8);
			bs=DER_BIT_STRING_new();
			if (bs == NULL) return(0);
			bs->length=len;
			bs->data=(unsigned char *)malloc(len+1);
			if (bs->data == NULL)
				{
				DERerr(DER_F_D2I_X509_NAME,ERR_R_MALLOC_FAILURE);
				return(0);
				}
			memcpy(bs->data,p,len);
			p+=len;
			bs->data[len]='\0';
			a->values[num_obj]=bs;

			num_obj++;
#if defined(DG_GCC_BUG) && !defined(LINT)
			bug=p;
#endif
			}
		if (p != p2)
			{
			DERerr(DER_F_D2I_X509_NAME,DER_R_LENGTH_MISMATCH);
			return(0);
			}
		}
	*pp=p;
	return(1);
	}

int D2i_X509_VAL(a, pp)
X509_VAL *a;
unsigned char **pp;
	{
	unsigned char *p;
	unsigned long len;
	int tag,class;

	p= *pp;
	DER_get_object(&p,&len,&tag,&class);
	if (tag != DER_SEQUENCE)
		{
		DERerr(DER_F_D2I_X509_VAL,DER_R_EXPECTING_A_SEQUENCE);
		return(0);
		}
	if (!D2i_UTCTime((unsigned char **)&(a->notBefore),&p)) return(0);
	if (!D2i_UTCTime((unsigned char **)&(a->notAfter),&p)) return(0);
	*pp=p;
	return(1);
	}

int D2i_X509_PUBKEY(a, pp)
X509_PUBKEY *a;
unsigned char **pp;
	{
	unsigned char *p;
	unsigned long len;
	int tag,class;

	p= *pp;
	DER_get_object(&p,&len,&tag,&class);
	if (tag != DER_SEQUENCE)
		{
		DERerr(DER_F_D2I_X509_PUBKEY,DER_R_EXPECTING_A_SEQUENCE);
		return(0);
		}
	if (!D2i_X509_ALGOR(a->algor,&p)) return(0);
	if (!D2i_DER_BIT_STRING(a->public_key,&p)) return(0);
	*pp=p;
	return(1);
	}

int D2i_X509_SIG(a, pp)
X509_SIG *a;
unsigned char **pp;
	{
	unsigned char *p;
	unsigned long len;
	int tag,class;

	p= *pp;
	DER_get_object(&p,&len,&tag,&class);
	if (tag != DER_SEQUENCE)
		{
		DERerr(DER_F_D2I_X509_SIG,DER_R_EXPECTING_A_SEQUENCE);
		return(0);
		}
	if (!D2i_X509_ALGOR(a->algor,&p)) return(0);
	if (!D2i_OCTET_STRING(a->digest,&p)) return(0);
	*pp=p;
	return(1);
	}

int D2i_X509_CINF(a, pp)
X509_CINF *a;
unsigned char **pp;
	{
	unsigned char *p;
	unsigned long len;
	int tag,class;

	p= *pp;
	DER_get_object(&p,&len,&tag,&class);
	if (tag != DER_SEQUENCE)
		{
		DERerr(DER_F_D2I_X509_CINF,DER_R_EXPECTING_A_SEQUENCE);
		return(0);
		}
/*	D2i_INTEGER(&(a->version),&p); *//* seems to be missing */
	if (!D2i_INTEGER(a->serialNumber,&p)) return(0);
	if (!D2i_X509_ALGOR(a->signature,&p)) return(0);
	if (!D2i_X509_NAME(a->issuer,&p)) return(0);
	if (!D2i_X509_VAL(a->validity,&p)) return(0);
	if (!D2i_X509_NAME(a->subject,&p)) return(0);
	if (!D2i_X509_PUBKEY(a->key,&p)) return(0);
	*pp=p;
	return(1);
	}

int D2i_X509_REVOKED(a, pp)
X509_REVOKED **a;
unsigned char **pp;
	{
	X509_REVOKED *r;
	unsigned char *p;
	unsigned long len;
	int tag,class;

	r=X509_REVOKED_new();
	if (r == NULL)
		{
		DERerr(DER_F_D2I_X509_REVOKED,ERR_R_MALLOC_FAILURE);
		return(0);
		}
	*a=r;

	p= *pp;
	DER_get_object(&p,&len,&tag,&class);
	if (tag != DER_SEQUENCE)
		{
		DERerr(DER_F_D2I_X509_REVOKED,DER_R_EXPECTING_A_SEQUENCE);
		return(0);
		}
	if (!D2i_INTEGER(r->serialNumber,&p)) return(0);
	if (!D2i_UTCTime((unsigned char **)&(r->revocationDate),&p)) return(0);
	*pp=p;
	return(1);
	}

static int D2i_X509_REVOKED_list(a, pp)
X509_CRL_INFO *a;
unsigned char **pp;
	{
	unsigned char *p,*q;
	unsigned long len,len2;
	int tag,class;
	unsigned int num=0;

	p= *pp;
	DER_get_object(&p,&len,&tag,&class);
	if (tag != DER_SEQUENCE)
		{
		DERerr(DER_F_D2I_X509_REVOKED_LIST,DER_R_EXPECTING_A_SEQUENCE);
		return(0);
		}
	q=p;
	len2=0;
	while (p < (q+len))
		{
		num++;
		DER_get_object(&p,&len2,&tag,&class);
		if (tag != DER_SEQUENCE)
			{
			DERerr(DER_F_D2I_X509_REVOKED_LIST,
				DER_R_EXPECTING_A_SEQUENCE);
			return(0);
			}
		p+=len2;
		}
	a->num=num;
	a->revoked=(X509_REVOKED **)malloc(sizeof(X509_REVOKED *)*num);
	if (a->revoked == NULL)
		{
		DERerr(DER_F_D2I_X509_REVOKED_LIST,ERR_R_MALLOC_FAILURE);
		return(0);
		}
	p=q;
	num=0;
	while (p < (q+len))
		{
		if (!D2i_X509_REVOKED(&(a->revoked[num++]),&p)) return(0);
		}
	*pp=p;
	return(1);
	}

int D2i_X509_CRL_INFO(a, pp)
X509_CRL_INFO *a;
unsigned char **pp;
	{
	unsigned char *p;
	unsigned long len;
	int tag,class;

	p= *pp;
	DER_get_object(&p,&len,&tag,&class);
	if (tag != DER_SEQUENCE)
		{
		DERerr(DER_F_D2I_X509_CRL_INFO,DER_R_EXPECTING_A_SEQUENCE);
		return(0);
		}
	if (!D2i_X509_ALGOR(a->sig_alg,&p)) return(0);
	if (!D2i_X509_NAME(a->issuer,&p)) return(0);
	if (!D2i_UTCTime((unsigned char **)&(a->lastUpdate),&p)) return(0);
	if (!D2i_UTCTime((unsigned char **)&(a->nextUpdate),&p)) return(0);
	if (!D2i_X509_REVOKED_list(a,&p)) return(0);
	*pp=p;
	return(1);
	}

int D2i_X509_CRL(a, lenbuf, p)
X509_CRL *a;
int lenbuf;
unsigned char *p;
	{
	unsigned long len;
	int tag,class;

	DER_get_object(&p,&len,&tag,&class);
	len=DER_object_size(1,(int)len,tag);
	if (lenbuf < len)
		{
		DERerr(DER_F_D2I_X509_CRL,DER_R_NOT_ENOUGH_DATA);
		return(0);
		}
	if (tag != DER_SEQUENCE)
		{
		DERerr(DER_F_D2I_X509_CRL,DER_R_EXPECTING_A_SEQUENCE);
		return(0);
		}
	if (!D2i_X509_CRL_INFO(a->crl,&p)) return(0);
	if (!D2i_X509_ALGOR(a->sig_alg,&p)) return(0);
	if (!D2i_DER_BIT_STRING(a->signature,&p)) return(0);
	return(1);
	}

int D2i_X509_CRL_file(file, a)
char *file;
X509_CRL *a;
	{
	int i;
	FILE *in;

	in=fopen(file,"r");
	if (in == NULL)
		{
		DERerr(ERR_F_FOPEN,errno);
		DERerr(DER_F_D2I_X509_CRL_FILE,ERR_R_SYS_LIB);
		return(0);
		}
	i=D2i_X509_CRL_fp(in,a);
	fclose(in);
	return(i);
	}

int D2i_X509_CRL_fp(in, a)
FILE *in;
X509_CRL *a;
	{
	BUFFER *b;
	int i,lenbuf=0;

	b=buffer_new();
	if (b == NULL)
		{
		DERerr(DER_F_D2I_X509_CRL_FP,ERR_R_MALLOC_FAILURE);
		return(0);
		}
	if (!buffer_grow(b,READ_CHUNK))
		{
		DERerr(DER_F_D2I_X509_CRL_FP,ERR_R_MALLOC_FAILURE);
		goto err;
		}
	
	for (;;)
		{
		i=Fread(&(b->data[lenbuf]),1,READ_CHUNK,in);
		if (i <= 0) break;
		lenbuf+=i;
		if (!buffer_grow(b,lenbuf+READ_CHUNK))
			{
			DERerr(DER_F_D2I_X509_CRL_FP,ERR_R_MALLOC_FAILURE);
			goto err;
			}
		}
	if (lenbuf < 50)
		{
		DERerr(DER_F_D2I_X509_CRL_FP,DER_R_NOT_ENOUGH_DATA);
		goto err;
		}
	i=D2i_X509_CRL(a,lenbuf,(unsigned char *)b->data);
	buffer_free(b);
	return(i);
err:
	buffer_free(b);
	return(0);
	}

int D2i_X509_file(file, a)
char *file;
X509 *a;
	{
	int i;
	FILE *in;

	in=fopen(file,"r");
	if (in == NULL)
		{
		DERerr(ERR_F_FOPEN,errno);
		DERerr(DER_F_D2I_X509_FILE,ERR_R_SYS_LIB);
		return(0);
		}
	i=D2i_X509_fp(in,a);
	fclose(in);
	return(i);
	}

int D2i_X509_fp(in, a)
FILE *in;
X509 *a;
	{
	BUFFER *b;
	int i,lenbuf=0;

	b=buffer_new();
	if (b == NULL)
		{ DERerr(DER_F_D2I_X509_FP,ERR_R_MALLOC_FAILURE); return(0); }
	if (!buffer_grow(b,READ_CHUNK))
		{ DERerr(DER_F_D2I_X509_FP,ERR_R_MALLOC_FAILURE); goto err; }
	
	for (;;)
		{
		i=Fread(&(b->data[lenbuf]),1,READ_CHUNK,in);
		if (i <= 0) break;
		lenbuf+=i;
		if (!buffer_grow(b,lenbuf+READ_CHUNK))
			{
			DERerr(DER_F_D2I_X509_FP,ERR_R_MALLOC_FAILURE);
			goto err;
			}
		}
	if (lenbuf < 10)
		{
		DERerr(DER_F_D2I_X509_FP,DER_R_NOT_ENOUGH_DATA);
		goto err;
		}
	i=D2i_X509(a,lenbuf,(unsigned char *)b->data);
	buffer_free(b);
	return(i);
err:
	buffer_free(b);
	return(0);
	}

int D2i_X509(a, lenbuf, p)
X509 *a;
int lenbuf;
unsigned char *p;
	{
	unsigned long len;
	int tag,class;

	DER_get_object(&p,&len,&tag,&class);
	len=DER_object_size(1,(int)len,tag);

	if (lenbuf < len)
		{
		DERerr(DER_F_D2I_X509,DER_R_NOT_ENOUGH_DATA);
		return(0);
		} 
	if (tag != DER_SEQUENCE)
		{
		DERerr(DER_F_D2I_X509,DER_R_EXPECTING_A_SEQUENCE);
		return(0);
		}
	if (!D2i_X509_CINF(a->cert_info,&p)) return(0);
	if (!D2i_X509_ALGOR(a->sig_alg,&p)) return(0);
	if (!D2i_DER_BIT_STRING(a->signature,&p)) return(0);
	return(1);
	}

int D2i_RSAPrivateKey_fp(in, rsa)
FILE *in;
RSA *rsa;
	{
	int i,lenbuf=0;
	BUFFER *b;
	unsigned char *pp;

	b=buffer_new();
	if (b == NULL)
		{
		DERerr(DER_F_D2I_RSAPRIVATEKEY_FP,ERR_R_MALLOC_FAILURE);
		return(0);
		}
	if (!buffer_grow(b,READ_CHUNK))
		{
		DERerr(DER_F_D2I_RSAPRIVATEKEY_FP,ERR_R_MALLOC_FAILURE);
		goto err;
		}
	
	for (;;)
		{
		i=Fread(&(b->data[lenbuf]),1,READ_CHUNK,in);
		if (i <= 0) break;
		lenbuf+=i;
		if (!buffer_grow(b,(long)lenbuf+READ_CHUNK))
			{
			DERerr(DER_F_D2I_RSAPRIVATEKEY_FP,ERR_R_MALLOC_FAILURE);
			goto err;
			}
		}
	if (lenbuf < 10)
		{
		DERerr(DER_F_D2I_RSAPRIVATEKEY_FP,DER_R_NOT_ENOUGH_DATA);
		goto err;
		}
	pp=(unsigned char *)b->data;
	i=D2i_RSAPrivateKey(rsa,&pp);
	buffer_free(b);
	return(i);
err:
	buffer_free(b);
	return(0);
	}

int D2i_RSAPrivateKey(rsa, pp)
RSA *rsa;
unsigned char **pp;
	{
	unsigned char *p;
	unsigned long len;
	int tag,class;
	DER_BIT_STRING bs;

	p= *pp;
	DER_get_object(&p,&len,&tag,&class);
	if (tag != DER_SEQUENCE)
		{
		DERerr(DER_F_D2I_RSAPRIVATEKEY,DER_R_EXPECTING_A_SEQUENCE);
		return(0);
		}
	bs.length=0; bs.data=NULL;
	if (!D2i_INTEGER(&bs,&p)) return(0); /* version */
	if (!D2i_INTEGER(&bs,&p)) return(0); /* n */
	rsa->n=bn_bin2bn(bs.length,bs.data,rsa->n);
	if (rsa->n == NULL)
		{ DERerr(DER_F_D2I_RSAPRIVATEKEY,ERR_R_RSA_LIB); return(0); }

	if (!D2i_INTEGER(&bs,&p)) return(0); /* e */
	rsa->e=bn_bin2bn(bs.length,bs.data,rsa->e);
	if (rsa->e == NULL)
		{ DERerr(DER_F_D2I_RSAPRIVATEKEY,ERR_R_RSA_LIB); return(0); }

	if (!D2i_INTEGER(&bs,&p)) return(0); /* d */
	rsa->d=bn_bin2bn(bs.length,bs.data,rsa->d);
	if (rsa->d == NULL)
		{ DERerr(DER_F_D2I_RSAPRIVATEKEY,ERR_R_RSA_LIB); return(0); }

	if (!D2i_INTEGER(&bs,&p)) return(0); /* p */
	rsa->p=bn_bin2bn(bs.length,bs.data,rsa->p);
	if (rsa->p == NULL)
		{ DERerr(DER_F_D2I_RSAPRIVATEKEY,ERR_R_RSA_LIB); return(0); }

	if (!D2i_INTEGER(&bs,&p)) return(0); /* q */
	rsa->q=bn_bin2bn(bs.length,bs.data,rsa->q);
	if (rsa->q == NULL)
		{ DERerr(DER_F_D2I_RSAPRIVATEKEY,ERR_R_RSA_LIB); return(0); }

	if (!D2i_INTEGER(&bs,&p)) return(0); /* dmp1 */
	rsa->dmp1=bn_bin2bn(bs.length,bs.data,rsa->dmp1);
	if (rsa->dmp1 == NULL)
		{ DERerr(DER_F_D2I_RSAPRIVATEKEY,ERR_R_RSA_LIB); return(0); }

	if (!D2i_INTEGER(&bs,&p)) return(0); /* dmq1 */
	rsa->dmq1=bn_bin2bn(bs.length,bs.data,rsa->dmq1);
	if (rsa->dmq1 == NULL)
		{ DERerr(DER_F_D2I_RSAPRIVATEKEY,ERR_R_RSA_LIB); return(0); }

	if (!D2i_INTEGER(&bs,&p)) return(0); /* iqmp */
	rsa->iqmp=bn_bin2bn(bs.length,bs.data,rsa->iqmp);
	if (rsa->iqmp == NULL)
		{ DERerr(DER_F_D2I_RSAPRIVATEKEY,ERR_R_RSA_LIB); return(0); }

	free(bs.data);
	*pp=p;
	return(1);
	}

int D2i_RSAPublicKey(rsa, pp)
RSA *rsa;
unsigned char **pp;
	{
	unsigned char *p;
	unsigned long len;
	int tag,class;
	DER_BIT_STRING bs;

	p= *pp;
	DER_get_object(&p,&len,&tag,&class);
	if (tag != DER_SEQUENCE)
		{
		DERerr(DER_F_D2I_RSAPUBLICKEY,DER_R_EXPECTING_A_SEQUENCE);
		return(0);
		}
	bs.length=0; bs.data=NULL;
	if (!D2i_INTEGER(&bs,&p)) return(0); /* n */
	rsa->n=bn_bin2bn(bs.length,bs.data,rsa->n);
	if (rsa->n == NULL)
		{ DERerr(DER_R_EXPECTING_A_SEQUENCE,ERR_R_RSA_LIB); return(0); }

	if (!D2i_INTEGER(&bs,&p)) return(0); /* e */
	rsa->e=bn_bin2bn(bs.length,bs.data,rsa->e);
	if (rsa->e == NULL)
		{ DERerr(DER_R_EXPECTING_A_SEQUENCE,ERR_R_RSA_LIB); return(0); }

	free(bs.data);
	*pp=p;
	return(1);
	}
