#!/bin/sh
#
# migrate.sh
#

me=`basename $0`

# test number of args
if [ $# -ne 3 ]; then
   echo "$me: got wrong number of arguments" >&2
   exit 1
fi

#
# Get the current checkpoint besides the regular copied one.
#

/home/reuti/check/checkpoint.sh $2 $3

#
# Now kill the job with the whole process group.
#

kill -9 -- -$1
