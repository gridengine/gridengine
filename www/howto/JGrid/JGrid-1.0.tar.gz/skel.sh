#!/bin/sh
#$ -S /bin/sh

#Change this to the location of the skeleton
JGRID_HOME=/opt/SGE/jgrid

#Change this to the working directory
WORK_DIR=/opt/SGE/jgrid/jobs

$JGRID_HOME/skeleton -d $WORK_DIR $@