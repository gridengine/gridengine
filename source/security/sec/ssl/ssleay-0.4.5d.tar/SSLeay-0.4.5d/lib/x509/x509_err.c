/* lib/x509/x509_err.c */
/* Copyright (C) 1995 Eric Young (eay@mincom.oz.au)
 * All rights reserved.
 * 
 * This file is part of an SSL implementation written
 * by Eric Young (eay@mincom.oz.au).
 * The implementation was written so as to conform with Netscapes SSL
 * specification.  This library and applications are
 * FREE FOR COMMERCIAL AND NON-COMMERCIAL USE
 * as long as the following conditions are aheared to.
 * 
 * Copyright remains Eric Young's, and as such any Copyright notices in
 * the code are not to be removed.  If this code is used in a product,
 * Eric Young should be given attribution as the author of the parts used.
 * This can be in the form of a textual message at program startup or
 * in documentation (online or textual) provided with the package.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by Eric Young (eay@mincom.oz.au)
 * 
 * THIS SOFTWARE IS PROVIDED BY ERIC YOUNG ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * 
 * The licence and distribution terms for any publically available version or
 * derivative of this code cannot be changed.  i.e. this code cannot simply be
 * copied and put under another distribution licence
 * [including the GNU Public Licence.]
 */

#include <stdio.h>
#include "crypto.h"
#include "x509.h"

static ERR_STRING_DATA X509_str_functs[]=
	{
{ERR_PACK(0,X509_F_BUFFER_NEW,0),	"buffer_new"},
{ERR_PACK(0,X509_F_BUFFER_GROW,0),	"buffer_grow"},
{ERR_PACK(0,X509_F_BUFFER_GET_BUF,0),	"buffer_get_buf"},
{ERR_PACK(0,X509_F_X509_ALGOR_NEW,0),	"X509_ALGOR_new"},
{ERR_PACK(0,X509_F_X509_NAME_NEW,0),	"X509_NAME_new"},
{ERR_PACK(0,X509_F_X509_VAL_NEW,0),	"X509_VAL_new"},
{ERR_PACK(0,X509_F_X509_PUBKEY_NEW,0),	"X509_PUBKEY_new"},
{ERR_PACK(0,X509_F_X509_SIG_NEW,0),	"X509_SIG_new"},
{ERR_PACK(0,X509_F_X509_CINF_NEW,0),	"X509_CINF_new"},
{ERR_PACK(0,X509_F_X509_REVOKED_NEW,0),	"X509_REVOKED_new"},
{ERR_PACK(0,X509_F_X509_CRL_INFO_NEW,0),	"X509_CRL_INFO_new"},
{ERR_PACK(0,X509_F_X509_CRL_NEW,0),	"X509_CRL_new"},
{ERR_PACK(0,X509_F_X509_NEW,0),	"X509_new"},
{ERR_PACK(0,X509_F_X509_DUP,0),	"X509_dup"},
{ERR_PACK(0,X509_F_X509_NEW_D2i_X509,0),	"X509_NEW_D2i_X509"},
{ERR_PACK(0,X509_F_X509_DUP_DER_OBJECT,0),	"X509_dup_DER_OBJECT"},
{ERR_PACK(0,X509_F_X509_ONELINE_X509_NAME,0),	"X509_oneline_X509_NAME"},
{ERR_PACK(0,X509_F_INIT_OBJ,0),	"INIT_OBJ"},
{ERR_PACK(0,X509_F_INIT_CERTS,0),	"INIT_CERTS"},
{ERR_PACK(0,X509_F_X509_GET_CERT,0),	"X509_get_cert"},
{ERR_PACK(0,X509_F_X509_ADD_CERT,0),	"X509_add_cert"},
{ERR_PACK(0,X509_F_X509_ADD_CERT_FILE,0),	"X509_add_cert_file"},
{ERR_PACK(0,X509_F_X509_ADD_CERT_DIR,0),	"X509_add_cert_dir"},
{ERR_PACK(0,X509_F_X509_REQ,0),	"X509_REQ"},
{ERR_PACK(0,X509_F_X509_REQ_INFO,0),	"X509_REQ_INFO"},
{ERR_PACK(0,X509_F_X509_NAME_DUP,0),	"X509_NAME_dup"},
{ERR_PACK(0,X509_F_X509_SIGN,0),	"X509_sign"},
{ERR_PACK(0,X509_F_X509_X509_TO_REQ,0),	"X509_X509_TO_req"},
{ERR_PACK(0,X509_F_X509_REQ_SIGN,0),	"X509_REQ_sign"},
{ERR_PACK(0,X509_F_X509_REQ_VERIFY,0),	"X509_REQ_verify"},
{0,NULL},
	};

static ERR_STRING_DATA X509_str_reasons[]=
	{
{X509_R_BAD_X509_FILETYPE                ,"bad x509 filetype"},
{X509_R_HIT_IN_OBJECT_STORAGE            ,"hit in object storage"},
{X509_R_HIT_IN_NID_STORAGE               ,"hit in nid storage"},
{X509_R_HIT_IN_SN_STORAGE                ,"hit in sn storage"},
{X509_R_HIT_IN_LN_STORAGE                ,"hit in ln storage"},
{X509_R_CERT_ALREADY_IN_HASH_TABLE       ,"cert already in hash table"},
{X509_R_UNKNOWN_OBJECT_TYPE              ,"unknown object type"},
{X509_R_UNSUPORTED_MD_ALGORITHM          ,"unsuported md algorithm"},
{0,NULL},
	};

void ERR_load_X509_strings()
	{
	static int init=1;

	if (init)
		{
		ERR_load_strings(ERR_LIB_X509,X509_str_functs);
		ERR_load_strings(ERR_LIB_X509,X509_str_reasons);
		init=0;
		}
	}

