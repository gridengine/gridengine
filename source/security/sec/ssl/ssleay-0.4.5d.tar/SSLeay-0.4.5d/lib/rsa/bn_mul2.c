/* lib/rsa/bn_mul2.c */
/* Copyright (C) 1995 Eric Young (eay@mincom.oz.au)
 * All rights reserved.
 * 
 * This file is part of an SSL implementation written
 * by Eric Young (eay@mincom.oz.au).
 * The implementation was written so as to conform with Netscapes SSL
 * specification.  This library and applications are
 * FREE FOR COMMERCIAL AND NON-COMMERCIAL USE
 * as long as the following conditions are aheared to.
 * 
 * Copyright remains Eric Young's, and as such any Copyright notices in
 * the code are not to be removed.  If this code is used in a product,
 * Eric Young should be given attribution as the author of the parts used.
 * This can be in the form of a textual message at program startup or
 * in documentation (online or textual) provided with the package.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by Eric Young (eay@mincom.oz.au)
 * 
 * THIS SOFTWARE IS PROVIDED BY ERIC YOUNG ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * 
 * The licence and distribution terms for any publically available version or
 * derivative of this code cannot be changed.  i.e. this code cannot simply be
 * copied and put under another distribution licence
 * [including the GNU Public Licence.]
 */

#include <stdio.h>
#include "crypto.h"
#include "bn.h"

#define			LBITS(a)	((a)&MASK2l)
#define			HBITS(a)	(((a)>>BITS4)&MASK2l)
#define			L2HBITS(a)	(((a)&MASK2l)<<BITS4)

/* r must be different to a and b */
int bn_mul(r, a, b)
BIGNUM *r;
BIGNUM *a;
BIGNUM *b;
	{
	int i,j,num,carry;
	int am,bm,rm,ai,bi;
	BN_ULONG *ap,*bp,*rp;
	BN_ULLONG T,tmp;

	if (a->top < b->top) { r=b; b=a; a=r; }

	rm=(a->top+b->top);
	if (bn_expand(r,(rm+1)*BITS2) == NULL) return(0);
	r->top=rm;
	r->neg=a->neg^b->neg;

	ap=a->d;
	bp=b->d;
	rp=r->d;
	rm--;
	am=a->top-1;
	bm=b->top-1;

	num=0;
	carry=0;
	T=0;
	for (j=0; j<rm; j++)
		{
		if (j <= am)
			{
			ai=j;
			bi=0;
			num=((ai < bm)?ai:bm)+1;
			}
		else
			{
			ai=am;
			bi=j-am;
			num=(bm-bi)+1;
			}
		tmp=0;
		T=(T>>32)|(BN_ULLONG)carry<<32;
		carry=0;
		for (i=num; i; i--)
			{
			tmp=(BN_ULLONG)ap[ai--]*bp[bi++];
			T+=tmp;
			carry+=((tmp>>32) > (T>>32));
			}
		*(rp++)=T&0xffffffff;
		}
	*(rp++)=(T>>32)&0xffffffff;
	/* *(rp++)=carry;  there will be no final carry */ 
	bn_fix_top(r);
	return(1);
	}

