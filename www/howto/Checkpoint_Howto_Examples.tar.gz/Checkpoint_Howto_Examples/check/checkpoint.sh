#!/bin/sh
#
# checkpoint.sh
#

#
# Copy a checkpoint file from the scratch directory of the
# job to the checkpoint directory.
#

me=`basename $0`

# test number of args
if [ $# -ne 2 ]; then
   echo "$me: got wrong number of arguments" >&2
   exit 1
fi

SGE_CKPT_JOB=$1/$2

if [ \! -e "$SGE_CKPT_JOB" ] ; then
    mkdir $SGE_CKPT_JOB
fi

if [ \! -d "$SGE_CKPT_JOB" ] ; then
    echo "Checkpoint subdirectory couldn't be found."
    exit 1
fi

while [ -z "$DONE" ] ; do
    cp $TMPDIR/checkpoint_5 $SGE_CKPT_JOB/checkpoint 2>/dev/null
    if [ "$?" -eq "0" ] ; then
        diff $TMPDIR/checkpoint_5 $SGE_CKPT_JOB/checkpoint 1>/dev/null 2>&1
        if [ "$?" -eq "0" ] ; then
            DONE="1"
        fi
    else
        DONE="1"
    fi
done

exit 0
