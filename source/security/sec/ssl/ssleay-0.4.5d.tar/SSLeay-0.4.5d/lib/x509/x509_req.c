/* lib/x509/x509_req.c */
/* Copyright (C) 1995 Eric Young (eay@mincom.oz.au)
 * All rights reserved.
 * 
 * This file is part of an SSL implementation written
 * by Eric Young (eay@mincom.oz.au).
 * The implementation was written so as to conform with Netscapes SSL
 * specification.  This library and applications are
 * FREE FOR COMMERCIAL AND NON-COMMERCIAL USE
 * as long as the following conditions are aheared to.
 * 
 * Copyright remains Eric Young's, and as such any Copyright notices in
 * the code are not to be removed.  If this code is used in a product,
 * Eric Young should be given attribution as the author of the parts used.
 * This can be in the form of a textual message at program startup or
 * in documentation (online or textual) provided with the package.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by Eric Young (eay@mincom.oz.au)
 * 
 * THIS SOFTWARE IS PROVIDED BY ERIC YOUNG ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * 
 * The licence and distribution terms for any publically available version or
 * derivative of this code cannot be changed.  i.e. this code cannot simply be
 * copied and put under another distribution licence
 * [including the GNU Public Licence.]
 */

#include <stdio.h>

#include "crypto.h"
#include "der.h"
#include "bn.h"
#include "x509.h"
#include "x509_obj.h"
#include "buffer.h"
#include "pem.h"

#define READ_CHUNK   2048

X509_REQ *X509_X509_TO_req(x,rsa)
X509 *x;
RSA *rsa;
	{
	X509_REQ *ret;
	X509_REQ_INFO *ri;
	X509_NAME *n;
	DER_OBJECT *obj;
	int i;
	unsigned char *s,*p;

	ret=X509_REQ_new();

	ri=ret->req_info;

	ri->version->length=1;
	ri->version->data=(unsigned char *)malloc(1);
	if (ri->version->data == NULL) goto err;
	ri->version->data[0]=0; /* version == 0 */

	n=X509_NAME_dup(x->cert_info->subject);
	if (n == NULL) goto err;

	X509_NAME_free(ri->subject); 
	ri->subject=n;

	obj=X509_dup_DER_OBJECT(X509_nid2obj(NID_rsaEncryption));
	if (obj == NULL) goto err;
	DER_OBJECT_free(ri->pubkey->algor->algorithm);
	ri->pubkey->algor->algorithm=obj;

	i=i2D_RSAPublicKey(rsa,NULL);
	s=(unsigned char *)malloc((unsigned int)i+1);
	if (s == NULL)
		{
		X509err(X509_F_X509_X509_TO_REQ,ERR_R_MALLOC_FAILURE);
		goto err;
		}
	p=s;
	i2D_RSAPublicKey(rsa,&p);
	ri->pubkey->public_key->length=i;
	ri->pubkey->public_key->data=s;

	if (!X509_REQ_sign(ret,rsa,PEM_MD_MD5_RSA))
		goto err;
	return(ret);
err:
	X509_REQ_free(ret);
	return(NULL);
	}

int X509_REQ_sign(x, rsa, type)
X509_REQ *x;
RSA *rsa;
int type;
	{
	PEM_CTX ctx;
	unsigned char *p,*buf_in,*buf_out;
	int inl,outl;

	inl=i2D_X509_REQ_INFO(x->req_info,NULL);
	buf_in=malloc((unsigned int)inl);
	outl=RSA_size(rsa);
	buf_out=malloc((unsigned int)outl);
	if ((buf_in == NULL) || (buf_out == NULL))
		{
		X509err(X509_F_X509_REQ_SIGN,ERR_R_MALLOC_FAILURE);
		if (buf_in != NULL) free(buf_in);
		return(0);
		}
	p=buf_in;
	i2D_X509_REQ_INFO(x->req_info,&p);
	if (	(!PEM_SignInit(&ctx,type)) ||
		(!PEM_SignUpdate(&ctx,(unsigned char *)buf_in,inl)) ||
		(!PEM_SignFinal(&ctx,(unsigned char *)buf_out,
		(unsigned int *)&outl,rsa)))
		{
		X509err(X509_F_X509_REQ_SIGN,ERR_R_PEM_LIB);
		free(buf_in);
		free(buf_out);
		return(0);
		}
	memset(buf_in,0,(unsigned int)inl);
	free(buf_in);

	x->sig_alg->type=DER_NULL;
	x->sig_alg->parameters->length=0;
	if (x->sig_alg->parameters->data != NULL)
		{
		free(x->sig_alg->parameters->data);
		x->sig_alg->parameters->data=NULL;
		}
	DER_OBJECT_free(x->sig_alg->algorithm);

	/* change to md? to md?withRSAEncryption */
#ifdef undef
	if (type == NID_md5withRSAEncryption)
		type=NID_md5;
	else if (type == NID_md2withRSAEncryption)
		type=NID_md2;
	else
		{
		X509err(X509_F_X509_REQ_SIGN,X509_R_UNSUPORTED_MD_ALGORITHM);
		free(buf_out);
		return(0);
		}
#endif

	x->sig_alg->algorithm=X509_dup_DER_OBJECT(X509_nid2obj(type));
	if (x->sig_alg->algorithm == NULL)
		{
		X509err(X509_F_X509_REQ_SIGN,X509_R_UNKNOWN_OBJECT_TYPE);
		free(buf_out);
		return(0);
		}
		
	if (x->signature->data != NULL) free(x->signature->data);
	x->signature->data=buf_out;
	x->signature->length=outl;
	return(outl);
	}

void X509_REQ_print(fp,x)
FILE *fp;
X509_REQ *x;
	{
	unsigned long l;
	int i,n;
	char *s,*p;
	X509_REQ_INFO *ri;
	RSA *rsa;

	ri=x->req_info;
	Fprintf(fp,"Certificate Request:\n");
	Fprintf(fp,"%4sData:\n","");
	for (l=i=0; i<ri->version->length; i++)
		{ l<<=8; l+=ri->version->data[i]; }
	Fprintf(fp,"%8sVersion: %ld (0x%lx)\n","",l,l);
	Fprintf(fp,"%8sSubject: ","");
	p=s=X509_oneline_X509_NAME(ri->subject);
	s++; /* skip the first slash */
	for (; *s; s++)
		{
		if (*s == '/')
			{
			Fputc(',',fp);
			Fputc(' ',fp);
			}
		else
			Fputc(*s,fp);
		}
	Fputc('\n',fp);
	free(p);
	Fprintf(fp,"%8sSubject Public Key Info:\n","");
	i=X509_obj2nid(ri->pubkey->algor->algorithm);
	Fprintf(fp,"%12sPublic Key Algorithm: %s\n","",
		(i == NID_undef)?"UNKNOWN":X509_nid2ln(i));
	Fprintf(fp,"%12sPublic Key:\n","");
	Fprintf(fp,"%16sModulus:","");

	rsa=RSA_new();
	s=(char *)ri->pubkey->public_key->data;
	D2i_RSAPublicKey(rsa,(unsigned char **)&s);
	i=RSA_size(rsa);
	s=(char *)malloc((unsigned int)i+10);
	n=bn_bn2bin(rsa->n,(unsigned char *)s);
	
	for (i=0; i<n; i++)
		{
		if ((i%15) == 0) Fprintf(fp,"\n%20s","");
		Fprintf(fp,"%02x%s",(unsigned char)s[i],((i+1) == n)?"":":");
		}
	free(s);
	Fputc('\n',fp);
	l=rsa->e->d[0];
	Fprintf(fp,"%16sExponent: %ld (0x%lx)\n","",l,l);
	RSA_free(rsa);

	/* may not be */
	Fprintf(fp,"%8sAttributes:\n","");
	Fprintf(fp,"%12sa0:00\n","");

	i=X509_obj2nid(x->sig_alg->algorithm);
	Fprintf(fp,"%4sSignature Algorithm: %s","",
		(i == NID_undef)?"UNKNOWN":X509_nid2ln(i));

	n=x->signature->length;
	s=(char *)x->signature->data;
	for (i=0; i<n; i++)
		{
		if ((i%18) == 0) Fprintf(fp,"\n%8s","");
		Fprintf(fp,"%02x%s",(unsigned char)s[i],((i+1) == n)?"":":");
		}
	Fputc('\n',fp);
	}

int D2i_X509_REQ_INFO(a,pp)
X509_REQ_INFO *a;
unsigned char **pp;
	{
	unsigned char *p;
	unsigned long len;
	int tag,class;

	p= *pp;
	DER_get_object(&p,&len,&tag,&class);
	if (tag != DER_SEQUENCE)
		{
		DERerr(DER_F_D2I_X509_REQ_INFO,DER_R_EXPECTING_A_SEQUENCE);
		return(0);
		}
	if (!D2i_INTEGER(a->version,&p)) return(0);
	if (!D2i_X509_NAME(a->subject,&p)) return(0);
	if (!D2i_X509_PUBKEY(a->pubkey,&p)) return(0);
	DER_get_object(&p,&len,&tag,&class);
	if ((tag != 0) || (class != (DER_CONSTRUCTED|DER_CONTEXT_SPECIFIC))
		|| (len != 0))
		{
		DERerr(DER_F_D2I_X509_REQ_INFO,DER_R_BAD_TAG);
		return(0);
		}
	*pp=p;
	return(1);
	}

int D2i_X509_REQ_fp(in, a)
FILE *in;
X509_REQ *a;
	{
	BUFFER *b;
	unsigned char *p;
	int i,lenbuf=0;

	b=buffer_new();
	if (b == NULL)
		{
		DERerr(DER_F_D2I_X509_REQ_FP,ERR_R_MALLOC_FAILURE);
		return(0);
		}
	if (!buffer_grow(b,READ_CHUNK))
		{
		DERerr(DER_F_D2I_X509_REQ_FP,ERR_R_MALLOC_FAILURE);
		goto err;
		}
	
	for (;;)
		{
		i=Fread(&(b->data[lenbuf]),1,READ_CHUNK,in);
		if (i <= 0) break;
		lenbuf+=i;
		if (!buffer_grow(b,lenbuf+READ_CHUNK))
			{
			DERerr(DER_F_D2I_X509_REQ_FP,ERR_R_MALLOC_FAILURE);
			goto err;
			}
		}
	if (lenbuf < 10)
		{
		DERerr(DER_F_D2I_X509_REQ_FP,DER_R_NOT_ENOUGH_DATA);
		goto err;
		}
	p=(unsigned char *)b->data;
	i=D2i_X509_REQ(a,&p);
	buffer_free(b);
	return(i);
err:
	buffer_free(b);
	return(0);
	}

int D2i_X509_REQ(a, pp)
X509_REQ *a;
unsigned char **pp;
	{
	unsigned char *p;
	unsigned long len;
	int tag,class;

	p= *pp;
	DER_get_object(&p,&len,&tag,&class);
	if (tag != DER_SEQUENCE)
		{
		DERerr(DER_F_D2I_X509_REQ,DER_R_EXPECTING_A_SEQUENCE);
		return(0);
		}
        if (!D2i_X509_REQ_INFO(a->req_info,&p)) return(0);
	if (!D2i_X509_ALGOR(a->sig_alg,&p)) return(0);
	if (!D2i_DER_BIT_STRING(a->signature,&p)) return(0);

	*pp=p;
	return(1);
	}

void i2f_X509_REQ_INFO(fp, a)
FILE *fp;
X509_REQ_INFO *a;
	{
	Fprintf(fp,"%s\n",STRING_REQ_INFO_BEGIN);
	i2f_DER_BIT_STRING(fp,a->version);
	i2f_X509_NAME(fp,a->subject);
	i2f_X509_PUBKEY(fp,a->pubkey);
	Fprintf(fp,"%s\n",STRING_REQ_INFO_END);
	}

void i2f_X509_REQ(fp, a)
FILE *fp;
X509_REQ *a;
	{
	Fprintf(fp,"%s\n",STRING_REQ_BEGIN);
	i2f_X509_REQ_INFO(fp,a->req_info);
	i2f_X509_ALGOR(fp,a->sig_alg);
	i2f_DER_BIT_STRING(fp,a->signature);
	Fprintf(fp,"%s\n",STRING_REQ_END);
	}

int i2D_X509_REQ_fp(fp, a)
FILE *fp;
X509_REQ *a;
	{
	int btos,r,ret;
	unsigned char *p;
	BUFFER *b;

	btos=buffer_get_tos();
	b=buffer_get_buf();
	if (b == NULL)
		{
		DERerr(DER_F_I2D_X509_REQ_FP,ERR_R_MALLOC_FAILURE);
		return(0);
		}
	
	r=i2D_X509_REQ(a,NULL);
	if (!buffer_grow(b,r))
		{
		DERerr(DER_F_I2D_X509_REQ_FP,ERR_R_MALLOC_FAILURE);
		goto err;
		}
	p=(unsigned char *)b->data;
	r=i2D_X509_REQ(a,&p);
	ret=Fwrite(b->data,(unsigned int)r,1,fp);
	buffer_set_tos(btos);
	return(ret);
err:
	buffer_set_tos(btos);
	return(0);
	}

int X509_REQ_verify(req)
X509_REQ *req;
	{
	PEM_CTX ctx;
	X509_REQ_INFO *ri;
	int type,j,ret;
	unsigned char *s,*p;
	RSA *rsa;

	ri=req->req_info;

	type=X509_obj2nid(req->sig_alg->algorithm);
	if (type == NID_undef)
		{
		X509err(X509_F_X509_REQ_VERIFY,X509_R_UNKNOWN_OBJECT_TYPE);
		return(-1);
		}
	rsa=RSA_new();
	if (rsa == NULL)
		{
		X509err(X509_F_X509_REQ_VERIFY,ERR_R_MALLOC_FAILURE);
		return(-1);
		}

	p=ri->pubkey->public_key->data;
	if (!D2i_RSAPublicKey(rsa,&p))
		{
		RSA_free(rsa);
		return(-1);
		}
	j=i2D_X509_REQ_INFO(ri,NULL);
	s=malloc((unsigned int)j);
	if (s == NULL)
		{
		RSA_free(rsa);
		X509err(X509_F_X509_REQ_VERIFY,ERR_R_MALLOC_FAILURE);
		return(-1);
		}
	p=s;
	i2D_X509_REQ_INFO(ri,&p);
	if (	(!PEM_VerifyInit(&ctx,type)) ||
		(!PEM_VerifyUpdate(&ctx,(unsigned char *)s,j)) ||
		(!PEM_VerifyFinal(&ctx,(unsigned char *)req->signature->data,
			req->signature->length,rsa)))
		ret=0;
	else
		ret=1;

	RSA_free(rsa);
	free(s);
	return(ret);
	}
