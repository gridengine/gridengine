/* lib/pem/pem.h */
/* Copyright (C) 1995 Eric Young (eay@mincom.oz.au)
 * All rights reserved.
 * 
 * This file is part of an SSL implementation written
 * by Eric Young (eay@mincom.oz.au).
 * The implementation was written so as to conform with Netscapes SSL
 * specification.  This library and applications are
 * FREE FOR COMMERCIAL AND NON-COMMERCIAL USE
 * as long as the following conditions are aheared to.
 * 
 * Copyright remains Eric Young's, and as such any Copyright notices in
 * the code are not to be removed.  If this code is used in a product,
 * Eric Young should be given attribution as the author of the parts used.
 * This can be in the form of a textual message at program startup or
 * in documentation (online or textual) provided with the package.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by Eric Young (eay@mincom.oz.au)
 * 
 * THIS SOFTWARE IS PROVIDED BY ERIC YOUNG ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * 
 * The licence and distribution terms for any publically available version or
 * derivative of this code cannot be changed.  i.e. this code cannot simply be
 * copied and put under another distribution licence
 * [including the GNU Public Licence.]
 */

#include "md2.h"
#include "md5.h"

#ifndef HEADER_PEM_H
#define HEADER_PEM_H

#define PEM_ERROR 	     	0
#define PEM_TYPE_ENCRYPTED      10
#define PEM_TYPE_MIC_ONLY       20
#define PEM_TYPE_MIC_CLEAR      30

#define PEM_DEK_DES_CBC         40
#define PEM_DEK_IDEA_CBC        45
#define PEM_DEK_DES_EDE         50
#define PEM_DEK_DES_ECB         60
#define PEM_DEK_RSA             70
#define PEM_DEK_RSA_MD2         80
#define PEM_DEK_RSA_MD5         90

#define PEM_MAX_MD_SIZE		16

#define PEM_MD_MD2		NID_md2
#define PEM_MD_MD5		NID_md5
#define PEM_MD_MD2_RSA		NID_md2withRSAEncryption
#define PEM_MD_MD5_RSA		NID_md5withRSAEncryption

#define	PEM_STRING_DES_CBC	"DES-CBC"
#define	PEM_STRING_DES_CBC_LEN	7
#define	PEM_STRING_IDEA_CBC	"IDEA-CBC"
#define	PEM_STRING_IDEA_CBC_LEN	8
#define	PEM_STRING_RSA		"RSA"
#define	PEM_STRING_RSA_LEN	9
#define	PEM_STRING_RSA_MD2	"RSA-MD2"
#define	PEM_STRING_RSA_MD2_LEN	7
#define	PEM_STRING_RSA_MD5	"RSA-MD5"
#define	PEM_STRING_RSA_MD5_LEN	7
#define	PEM_STRING_DES_ECB	"DES_ECB"
#define	PEM_STRING_DES_ECB_LEN	7
#define	PEM_STRING_DES_EDE	"DES_EDE"
#define	PEM_STRING_DES_EDE_LEN	7
#define PEM_STRING_BAD_DAK	"BAD_DAK"
#define	PEM_STRING_BAD_DAK_LEN	7

typedef struct PEM_Digest_Ctx_st
	{
	int type;
	union	{
		union	{
			MD2_CTX md2;
			MD5_CTX md5;
			} md;
		union	{
			int encrypt;		/* encrypt or decrypt */
			int block;		/* block size (max 8) */
			int left;
			unsigned char buf[8];
			int cipher_size;	/* how big it is for zeroing */
			char *cipher;		/* cipher context */
			} c;
		} d;
	} PEM_CTX;

typedef struct PEM_Encode_Ctx_st
	{
	int count;
	unsigned char data[65];
	} PEM_ENCODE_CTX;

#ifdef PROTO
int	PEM_bin2ascii(int len, unsigned char *f, unsigned char *t);
int	PEM_ascii2bin(unsigned char *f, unsigned char *t);
int	PEM_do_header (char *header, int len, unsigned char *data);
void	PEM_set_getkey_callback(int (*a) ());
int	PEM_write_X509(FILE *fp, X509 *x);
int	PEM_read (FILE *fp, char **name, char **header, long *len, unsigned char **data);
int	PEM_read_RSA(FILE *fp, RSA *x);
int	PEM_read_X509(FILE *fp, X509 *x);
int	PEM_write (FILE *fp, char *name, char *header, long len, unsigned char *data);
int	PEM_write_RSA(FILE *fp, RSA *r, int enc, int klen, char *kstr);

int	PEM_write_X509_REQ(FILE *fp, X509_REQ *x);
int	PEM_write_X509_CRL(FILE *fp, X509_CRL *x);
int	PEM_read_X509_REQ(FILE *fp, X509_REQ *x);
int	PEM_read_X509_CRL(FILE *fp, X509_CRL *x);

int	PEM_DigestInit(PEM_CTX *ctx, int type);
int	PEM_DigestUpdate(PEM_CTX *ctx,unsigned char *d,unsigned int cnt);
int	PEM_DigestFinal(PEM_CTX *ctx,unsigned char *md,unsigned int *s);

int	PEM_SignInit(PEM_CTX *ctx, int type);
int	PEM_SignUpdate(PEM_CTX *ctx,unsigned char *d,unsigned int cnt);
int	PEM_SignFinal(PEM_CTX *ctx,unsigned char *md,unsigned int *s, RSA *rsa);

int	PEM_VerifyInit(PEM_CTX *ctx, int type);
int	PEM_VerifyUpdate(PEM_CTX *ctx,unsigned char *d,unsigned int cnt);
int	PEM_VerifyFinal(PEM_CTX *ctx,unsigned char *md,unsigned int s, RSA *rsa);

int	PEM_EncryptInit(PEM_CTX *ctx, unsigned char **enc_keys,
	unsigned int *enc_keylen, unsigned char *ret_iv,
	unsigned int num_pkeys, RSA **pkeys, int type);
int	PEM_EncryptUpdate(PEM_CTX *ctx, unsigned char *out,
	unsigned int *outl, unsigned char *in, unsigned int inl);
int	PEM_EncryptFinal(PEM_CTX *ctx, unsigned char *out,
	unsigned int outl);
void	PEM_EncryptFinished(PEM_CTX *ctx);

int	PEM_DecryptInit(PEM_CTX *ctx, int type, unsigned char *enc_key,
	unsigned int enc_key_len, unsigned char *iv, RSA *rsa);
int	PEM_DecryptUpdate(PEM_CTX *ctx, unsigned char *out,
	unsigned int *outl, unsigned char *in, unsigned int inl);
int	PEM_DecryptFinal(PEM_CTX *ctx, unsigned char *outm,
	unsigned int *outl);
void	PEM_DecryptFinished(PEM_CTX *ctx);

#else

int	PEM_bin2ascii();
int	PEM_ascii2bin();
int	PEM_do_header ();
void	PEM_set_getkey_callback();
int	PEM_write_X509();
int	PEM_read ();
int	PEM_read_RSA();
int	PEM_read_X509();
int	PEM_write ();
int	PEM_write_RSA();
int	PEM_write_X509_REQ();
int	PEM_read_X509_REQ();
int	PEM_write_X509_CRL();
int	PEM_read_X509_CRL();

int	PEM_DigestInit();
int	PEM_DigestUpdate();
int	PEM_DigestFinal();

int	PEM_SignInit();
int	PEM_SignUpdate();
int	PEM_SignFinal();

int	PEM_VerifyInit();
int	PEM_VerifyUpdate();
int	PEM_VerifyFinal();

int	PEM_EncryptInit();
int	PEM_EncryptUpdate();
int	PEM_EncryptFinal();
void	PEM_EncryptFinished();

int	PEM_DecryptInit();
int	PEM_DecryptUpdate();
int	PEM_DecryptFinal();
void	PEM_DecryptFinished();

#endif

#endif
