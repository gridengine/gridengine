/* apps/x509.c */
/* Copyright (C) 1995 Eric Young (eay@mincom.oz.au)
 * All rights reserved.
 * 
 * This file is part of an SSL implementation written
 * by Eric Young (eay@mincom.oz.au).
 * The implementation was written so as to conform with Netscapes SSL
 * specification.  This library and applications are
 * FREE FOR COMMERCIAL AND NON-COMMERCIAL USE
 * as long as the following conditions are aheared to.
 * 
 * Copyright remains Eric Young's, and as such any Copyright notices in
 * the code are not to be removed.  If this code is used in a product,
 * Eric Young should be given attribution as the author of the parts used.
 * This can be in the form of a textual message at program startup or
 * in documentation (online or textual) provided with the package.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by Eric Young (eay@mincom.oz.au)
 * 
 * THIS SOFTWARE IS PROVIDED BY ERIC YOUNG ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * 
 * The licence and distribution terms for any publically available version or
 * derivative of this code cannot be changed.  i.e. this code cannot simply be
 * copied and put under another distribution licence
 * [including the GNU Public Licence.]
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "apps.h"
#include "err.h"
#include "der.h"
#include "bn.h"
#include "x509.h"
#include "x509_obj.h"
#include "pem.h"

#define PROG x509_main

#define	POSTFIX	".srl"
#define DEF_DAYS	30

#define FORMAT_UNDEF	0
#define FORMAT_DER	1
#define FORMAT_TEXT	2
#define FORMAT_PEM	3

char *usage[]={
"usage: x509 args\n",
"\n",
" -inform arg     - input format - default PEM (one of DER, TXT or PEM)\n",
" -outform arg    - output format - default PEM\n",
" -keyform arg    - rsa key format - default PEM\n",
" -CAform arg     - CA format - default PEM\n",
" -CAkeyform arg  - CA key format - default PEM\n",
" -days arg       - How long till expiry of a signed certificate - def 30 days\n",
" -in arg         - input file - default stdin\n",
" -out arg        - output file - default stdout\n",
" -serial         - print serial number value\n",
" -hash           - print hash value\n",
" -subject        - print subject DN\n",
" -issuer         - print issuer DN\n",
" -startdate      - notBefore field\n",
" -enddate        - notAfter field\n",
" -noout          - no certificate output\n",
" -signkey arg    - set issuer to subject and sign with private key and\n",
"                   put the public in cert.\n",
" -RSAreq arg     - output a certification request object\n",
" -CA arg         - set the CA certificate, must be PEM format.\n",
" -CAkey arg      - set the CA RSA key, must be PEM format, if this arg\n",
"                   missing, it is asssumed to be in the CA file.\n",
" -CAcreateserial - create serial number file if it does not exist\n",
" -CAserial       - serial file\n",
NULL
};

#ifdef PROTO
static int callb(int ok, X509 *xs, X509 *xi, int depth, int error);
static RSA *load_key(char *file, int format);
static X509 *load_cert(char *file, int format);
static int sign (X509 *x, RSA *rsa);
static int certify (char *CAfile, X509 *x, X509 *xca, RSA *rsa, 
	char *serial, int create, int days);
#else
static int callb();
static RSA *load_key();
static X509 *load_cert();
static int sign ();
static int certify ();
#endif

int MAIN(argc, argv)
int argc;
char **argv;
	{
	X509 *x=NULL,*xca=NULL;
	RSA *rsa=NULL,*CArsa=NULL;
	int i,num,badops=0;
	FILE *out=NULL;
	int informat,outformat,keyformat,CAformat,CAkeyformat;
	char *infile=NULL,*outfile=NULL,*keyfile=NULL,*CAfile=NULL;
	char *CAkeyfile=NULL,*str=NULL,*CAserial=NULL;
	int serial=0,hash=0,subject=0,issuer=0,startdate=0,enddate=0;
	int noout=0,sign_flag=0,CA_flag=0,CA_createserial=0;
	int RSAreq=0,days=DEF_DAYS;
	char *reqfile=NULL;
	char **pp;

	informat=FORMAT_PEM;
	outformat=FORMAT_PEM;
	keyformat=FORMAT_PEM;
	CAformat=FORMAT_PEM;
	CAkeyformat=FORMAT_PEM;

	argc--;
	argv++;
	num=0;
	while (argc >= 1)
		{
		if 	(strcmp(*argv,"-inform") == 0)
			{
			if (--argc < 1) goto bad;
			informat=str2fmt(*(++argv));
			}
		else if (strcmp(*argv,"-outform") == 0)
			{
			if (--argc < 1) goto bad;
			outformat=str2fmt(*(++argv));
			}
		else if (strcmp(*argv,"-keyform") == 0)
			{
			if (--argc < 1) goto bad;
			keyformat=str2fmt(*(++argv));
			}
		else if (strcmp(*argv,"-CAform") == 0)
			{
			if (--argc < 1) goto bad;
			CAformat=str2fmt(*(++argv));
			}
		else if (strcmp(*argv,"-CAkeyform") == 0)
			{
			if (--argc < 1) goto bad;
			CAformat=str2fmt(*(++argv));
			}
		else if (strcmp(*argv,"-days") == 0)
			{
			if (--argc < 1) goto bad;
			days=atoi(*(++argv));
			if (days == 0)
				{
				fprintf(stderr,"bad number of days\n");
				goto bad;
				}
			}
		else if (strcmp(*argv,"-in") == 0)
			{
			if (--argc < 1) goto bad;
			infile= *(++argv);
			}
		else if (strcmp(*argv,"-out") == 0)
			{
			if (--argc < 1) goto bad;
			outfile= *(++argv);
			}
		else if (strcmp(*argv,"-signkey") == 0)
			{
			if (--argc < 1) goto bad;
			keyfile= *(++argv);
			sign_flag= ++num;
			}
		else if (strcmp(*argv,"-CA") == 0)
			{
			if (--argc < 1) goto bad;
			CAfile= *(++argv);
			CA_flag= ++num;
			}
		else if (strcmp(*argv,"-CAkey") == 0)
			{
			if (--argc < 1) goto bad;
			CAkeyfile= *(++argv);
			}
		else if (strcmp(*argv,"-CAserial") == 0)
			{
			if (--argc < 1) goto bad;
			CAserial= *(++argv);
			}
		else if (strcmp(*argv,"-serial") == 0)
			serial= ++num;
		else if (strcmp(*argv,"-RSAreq") == 0)
			{
			if (--argc < 1) goto bad;
			reqfile= *(++argv);
			RSAreq= ++num;
			}
		else if (strcmp(*argv,"-hash") == 0)
			hash= ++num;
		else if (strcmp(*argv,"-subject") == 0)
			subject= ++num;
		else if (strcmp(*argv,"-issuer") == 0)
			issuer= ++num;
		else if (strcmp(*argv,"-startdate") == 0)
			startdate= ++num;
		else if (strcmp(*argv,"-enddate") == 0)
			enddate= ++num;
		else if (strcmp(*argv,"-noout") == 0)
			noout= ++num;
		else if (strcmp(*argv,"-CAcreateserial") == 0)
			CA_createserial= ++num;
		else
			{
			fprintf(stderr,"unknown option %s\n",*argv);
			badops=1;
			break;
			}
		argc--;
		argv++;
		}

	if (badops)
		{
bad:
		for (pp=usage; (*pp != NULL); pp++)
			fprintf(stderr,*pp);
		EXIT(1);
		}

	ERR_load_crypto_strings();

	if (!X509_set_default_verify_paths())
		{
		ERR_print_errors(stderr);
		EXIT(1);
		}

	if ((CAkeyfile == NULL) && (CA_flag) && (CAformat == FORMAT_PEM))
		{ CAkeyfile=CAfile; }
	else if ((CA_flag) && (CAkeyfile == NULL))
		{
		fprintf(stderr,"need to specify a CAkey if using the CA command\n");
		EXIT(1);
		}

	x=load_cert(infile,informat);
	if (x == NULL) { EXIT(1); }
	if (CA_flag)
		{
		xca=load_cert(CAfile,CAformat);
		if (xca == NULL) { EXIT(1); }
		}

	if (num)
		{
		for (i=1; i<=num; i++)
			{
			if (issuer == i)
				{
				str=X509_oneline_X509_NAME(X509_get_issuer_name(x));
				if (str == NULL)
					{
					fprintf(stderr,"unable to get issuer Name from certificate\n");
					ERR_print_errors(stderr);
					EXIT(1);
					}
				fprintf(stdout,"issuer= %s\n",str);
				free(str);
				}

			if (subject == i) 
				{
				str=X509_oneline_X509_NAME(X509_get_subject_name(x));
				if (str == NULL)
					{
					fprintf(stderr,"unable to get subject Name from certificate\n");
					ERR_print_errors(stderr);
					EXIT(1);
					}
				fprintf(stdout,"subject=%s\n",str);
				free(str);
				}
			if (serial == i)
				{
				fprintf(stdout,"serial ");
				i2f_DER_BIT_STRING(stdout,x->cert_info->serialNumber);
				}
			if (hash == i)
				{
				fprintf(stdout,"%08lx\n",
					X509_subject_name_hash(x));
				}
			if (startdate == i)
				{
				fprintf(stdout,"notBefore=%s\n",
					x->cert_info->validity->notBefore);
				}
			if (enddate == i)
				{
				fprintf(stdout,"notAfter =%s\n",
					x->cert_info->validity->notAfter);
				}

			/* should be in the library */
			if (sign_flag == i)
				{
				fprintf(stderr,"Getting Private key\n");
				if (rsa == NULL)
					{
					rsa=load_key(keyfile,keyformat);
					if (rsa == NULL) { EXIT(1); }
					}
				if (!sign(x,rsa)) { EXIT(1); }
				}
			if (CA_flag == i)
				{
				fprintf(stderr,"Getting CA Private Key\n");
				if (CAkeyfile != NULL)
					{
					CArsa=load_key(CAkeyfile,CAkeyformat);
					if (CArsa == NULL) { EXIT(1); }
					}
				if (!certify(CAfile,x,xca,CArsa,CAserial,
					CA_createserial,days))
					{ EXIT(1); }
				}
			if (RSAreq == i)
				{
				X509_REQ *rq;
				RSA *r;

				fprintf(stderr,"Getting request Private Key\n");
				if (reqfile == NULL)
					{
					fprintf(stderr,"no request key file specified\n");
					EXIT(1);
					}
				else
					{
					r=load_key(reqfile,FORMAT_PEM);
					if (r == NULL) { EXIT(1); }
					}

				fprintf(stderr,"Generating request to send to RSA\n");

				rq=(X509_REQ *)X509_X509_TO_req(x,r);
				if (rq == NULL)
					{
					ERR_print_errors(stderr);
					EXIT(1);
					}
				if (!noout)
					{
					if (outfile == NULL)
						out=stdout;
					else
						{
						out=fopen(outfile,"w");
						if (out == NULL)
							{
							perror(outfile);
							EXIT(1);
							}
						}
					X509_REQ_print(out,rq);
					PEM_write_X509_REQ(out,rq);
					if (out != stdout) fclose(out);
					}
				noout=1;
				X509_REQ_free(rq);
				}
			}
		}

	if (noout) goto end;

	if (outfile == NULL)
		out=stdout;
	else
		{
		out=fopen(outfile,"w");
		if (out == NULL) { perror(outfile); EXIT(1); }
		}

	if 	(outformat == FORMAT_DER)
		i=i2D_X509_fp(out,x);
	else if (outformat == FORMAT_TEXT)
		{ i2f_X509(out,x); i=1; }
	else if (outformat == FORMAT_PEM)
		i=PEM_write_X509(out,x);
	else	{
		fprintf(stderr,"bad output format specified for outfile\n");
		EXIT(1);
		}
	if (!i) {
		fprintf(stderr,"unable to write certificate\n");
		ERR_print_errors(stderr);
		EXIT(1);
		}
	if (out != stdout) fclose(out);
end:
	EXIT(0);
	}

static int certify(CAfile, x, xca, rsa, serialfile, create,days)
char *CAfile;
X509 *x;
X509 *xca;
RSA *rsa;
char *serialfile;
int create;
int days;
	{
	FILE *io;
	char *buf,buf2[1024];
	BIGNUM *serial;
	DER_BIT_STRING *bs,bs2;

	buf=(char *)malloc(RSA_size(rsa)*2+
		((serialfile == NULL)
			?(strlen(CAfile)+strlen(POSTFIX))
			:(strlen(serialfile)))+1);
	if (buf == NULL) { fprintf(stderr,"out of mem\n"); return(0); }
	if (serialfile == NULL)
		{
		strcpy(buf,CAfile);
		strcat(buf,POSTFIX);
		}
	else
		strcpy(buf,serialfile);
	serial=bn_new();
	bs=DER_BIT_STRING_new();
	if ((serial == NULL) || (bs == NULL))
		{
		ERR_print_errors(stderr);
		return(0);
		}

	io=fopen(buf,"r");
	if (io == NULL)
		{
		if (!create)
			{
			perror(buf);
			return(0);
			}
		else
			bn_zero(serial);
		}
	else 
		{
		if (!f2i_DER_BIT_STRING(io,bs,1024,buf2))
			{
			fprintf(stderr,"unable to load serial number from %s\n",buf);
			ERR_print_errors(stderr);
			fclose(io);
			return(0);
			}
		else
			{
			serial=bn_bin2bn(bs->length,bs->data,serial);
			if (serial == NULL)
				{
				fprintf(stderr,"error converting bin 2 bn");
				return(0);
				}
			}
		fclose(io);
		}

	if (!bn_add_word(serial,1))
		{ fprintf(stderr,"add_word failure\n"); return(0); }
	bs2.data=(unsigned char *)buf2;
	bs2.length=bn_bn2bin(serial,bs2.data);

	io=fopen(buf,"w");
	if (io == NULL)
		{
		fprintf(stderr,"error attempting to write serial number file\n");
		perror(buf);
		return(0);
		}
	i2f_DER_BIT_STRING(io,&bs2);
	fclose(io);
	
	if (!X509_add_cert(x)) return(0);
	/* NOTE: this certificate can/should be self signed */
	if (!X509_verify(x,callb)) return(0);

	/* don't free this X509 struct or bad things will happen
	 * unless you put issuer first :-) */
	x->cert_info->issuer=xca->cert_info->subject;
	if (x->cert_info->validity->notBefore == NULL)
		free(x->cert_info->validity->notBefore);
	x->cert_info->validity->notBefore=(char *)malloc(100);
	x->cert_info->serialNumber=bs;

	if (x->cert_info->validity->notBefore == NULL)
		{
		fprintf(stderr,"out of mem\n");
		return(0);
		}

	X509_gmtime(x->cert_info->validity->notBefore,0);
	/* hardwired expired */
	X509_gmtime(x->cert_info->validity->notAfter,60*60*24*days);
	if (!X509_sign(x,rsa,NID_md5withRSAEncryption))
		{
		ERR_print_errors(stderr);
		return(0);
		}
	return(1);
	}

static int callb(ok, xs, xi, depth, error)
int ok;
X509 *xs;
X509 *xi;
int depth;
int error;
	{
	/* it is ok to use a self signed certificate */
	if ((!ok) && (error == VERIFY_ERR_DEPTH_ZERO_SELF_SIGNED_CERT))
		return(1);

	/* BAD we should have gotten an error :-) */
	if (ok)
		printf("error with certificate to be certified - should be self signed\n");
	else
		{
		char *s;

		s=X509_oneline_X509_NAME(X509_get_subject_name(xs));
		printf("%s\n",s);
		free(s);
		printf("error with certificate - error %d at depth %d\n%s\n",
			error,depth,X509_verify_error_string(error));
		}
#ifdef LINT
	xi=xs; xs=xi;
#endif
	return(0);
	}

static RSA *load_key(file, format)
char *file;
int format;
	{
	FILE *key;
	RSA *rsa;
	int i;

	if (file == NULL)
		{
		fprintf(stderr,"no keyfile specified\n");
		return(NULL);
		}
	key=fopen(file,"r");
	if (key == NULL) { perror(file); return(NULL); }
	rsa=RSA_new();
	if (rsa == NULL)
		{
		ERR_print_errors(stderr);
		return(NULL);
		}
	if	(format == FORMAT_DER)
		i=D2i_RSAPrivateKey_fp(key,rsa);
	else if (format == FORMAT_TEXT)
		i=f2i_RSAPrivateKey(key,rsa);
	else if (format == FORMAT_PEM)
		i=PEM_read_RSA(key,rsa);
	else
		{
		fprintf(stderr,"bad input format specified for key\n");
		return(NULL);
		}
	fclose(key);
	if (!i)
		{
		fprintf(stderr,"unable to load Private Key\n");
		return(NULL);
		}
	return(rsa);
	}

static X509 *load_cert(file, format)
char *file;
int format;
	{
	X509 *x;
	FILE *cert;
	int i;

	if (file == NULL)
		cert=stdin;
	else
		{
		cert=fopen(file,"r");
		if (cert == NULL) { perror(file); return(NULL); }
		}
	x=X509_new();
	if (x == NULL)
		{
		ERR_print_errors(stderr);
		return(NULL);
		}
	if 	(format == FORMAT_DER)
		i=D2i_X509_fp(cert,x);
	else if (format == FORMAT_TEXT)
		i=f2i_X509(cert,x);
	else if (format == FORMAT_PEM)
		i=PEM_read_X509(cert,x);
	else	{
		fprintf(stderr,"bad input format specified for input cert\n");
		return(NULL);
		}
	if (!i)
		{
		fprintf(stderr,"unable to load certificate\n");
		ERR_print_errors(stderr);
		return(NULL);
		}
	if (cert != stdin) fclose(cert);
	return(x);
	}

static int sign(x, rsa)
X509 *x;
RSA *rsa;
	{
	int j;
	unsigned char *p;
	/* X509_NAME *n; */

	/* n=x->cert_info->subject; */
	/* don't free this X509 struct or bad
	 * things will happen unless you put
	 * n back first :-) */
	x->cert_info->issuer=x->cert_info->subject;
	X509_gmtime(x->cert_info->validity->notBefore,0);
	X509_gmtime(x->cert_info->validity->notAfter,60*60*24*28); /* 28 days to be certified */
	j=i2D_RSAPublicKey(rsa,NULL);
	p=x->cert_info->key->public_key->data=(unsigned char *)malloc(
		(unsigned int)j+10);
	if (p == NULL) { fprintf(stderr,"out of memory\n"); return(0); }

	x->cert_info->key->public_key->length=j;
	if (!i2D_RSAPublicKey(rsa,&p))
		{
		ERR_print_errors(stderr);
		return(0);
		}
	if (!X509_sign(x,rsa,NID_md5withRSAEncryption))
		{
		ERR_print_errors(stderr);
		return(0);
		}
	return(1);
	}
