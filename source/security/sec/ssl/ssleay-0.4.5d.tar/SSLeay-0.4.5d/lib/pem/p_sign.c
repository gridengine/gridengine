/* lib/pem/p_sign.c */
/* Copyright (C) 1995 Eric Young (eay@mincom.oz.au)
 * All rights reserved.
 * 
 * This file is part of an SSL implementation written
 * by Eric Young (eay@mincom.oz.au).
 * The implementation was written so as to conform with Netscapes SSL
 * specification.  This library and applications are
 * FREE FOR COMMERCIAL AND NON-COMMERCIAL USE
 * as long as the following conditions are aheared to.
 * 
 * Copyright remains Eric Young's, and as such any Copyright notices in
 * the code are not to be removed.  If this code is used in a product,
 * Eric Young should be given attribution as the author of the parts used.
 * This can be in the form of a textual message at program startup or
 * in documentation (online or textual) provided with the package.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by Eric Young (eay@mincom.oz.au)
 * 
 * THIS SOFTWARE IS PROVIDED BY ERIC YOUNG ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * 
 * The licence and distribution terms for any publically available version or
 * derivative of this code cannot be changed.  i.e. this code cannot simply be
 * copied and put under another distribution licence
 * [including the GNU Public Licence.]
 */

#include <stdio.h>
#include "crypto.h"
#include "md2.h"
#include "md5.h"
#include "der.h"
#include "x509.h"
#include "pem.h"

int PEM_SignInit(ctx,type)
PEM_CTX *ctx;
int type;
	{
	return(PEM_DigestInit(ctx,type));
	}

int PEM_SignUpdate(ctx,data,count)
PEM_CTX *ctx;
unsigned char *data;
unsigned int count;
	{
	return(PEM_DigestUpdate(ctx,data,count));
	}

int PEM_SignFinal(ctx,sigret,siglen,rsa)
PEM_CTX *ctx;
unsigned char *sigret;
unsigned int *siglen;
RSA *rsa;
	{
	unsigned char m[PEM_MAX_MD_SIZE];
	unsigned int m_len;
	int i,j,ret=1;
	X509_SIG sig;
        X509_ALGOR algor;
	DER_BIT_STRING parameters;
	DER_BIT_STRING digest;
	unsigned char *p,*s;

	if (!PEM_DigestFinal(ctx,&(m[0]),&m_len)) return(0);

	sig.algor= &algor;
	sig.algor->algorithm=X509_nid2obj(ctx->type);
	if (sig.algor->algorithm == NULL)
		{ PEMerr(PEM_F_PEM_SIGNFINAL,ERR_R_X509_LIB); return(0); }
	parameters.length=0;
	parameters.data=NULL;
	sig.algor->parameters= &parameters;
	sig.algor->type=DER_NULL;

	sig.digest= &digest;
	sig.digest->data=m;
	sig.digest->length=m_len;

	i=i2D_X509_SIG(&sig,NULL);
	j=RSA_size(rsa);
	if (i > j)
		{
		RSAerr(PEM_F_PEM_SIGNFINAL,RSA_R_DIGEST_KEY_TOO_BIG_FOR_KEY);
		return(0);
		}
	s=(unsigned char *)malloc((unsigned int)j+1);
	if (s == NULL)
		{ PEMerr(PEM_F_PEM_SIGNFINAL,ERR_R_MALLOC_FAILURE); return(0); }
	p=s;
	i2D_X509_SIG(&sig,&p);
	i=RSA_private_encrypt(i,s,sigret,rsa);
	if (i <= 0)
		ret=0;
	else
		*siglen=i;

	memset(s,0,(unsigned int)j+1);
	free(s);
	return(ret);
	}
