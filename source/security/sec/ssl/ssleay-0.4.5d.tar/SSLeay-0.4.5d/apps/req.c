/* apps/req.c */
/* Copyright (C) 1995 Eric Young (eay@mincom.oz.au)
 * All rights reserved.
 * 
 * This file is part of an SSL implementation written
 * by Eric Young (eay@mincom.oz.au).
 * The implementation was written so as to conform with Netscapes SSL
 * specification.  This library and applications are
 * FREE FOR COMMERCIAL AND NON-COMMERCIAL USE
 * as long as the following conditions are aheared to.
 * 
 * Copyright remains Eric Young's, and as such any Copyright notices in
 * the code are not to be removed.  If this code is used in a product,
 * Eric Young should be given attribution as the author of the parts used.
 * This can be in the form of a textual message at program startup or
 * in documentation (online or textual) provided with the package.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by Eric Young (eay@mincom.oz.au)
 * 
 * THIS SOFTWARE IS PROVIDED BY ERIC YOUNG ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * 
 * The licence and distribution terms for any publically available version or
 * derivative of this code cannot be changed.  i.e. this code cannot simply be
 * copied and put under another distribution licence
 * [including the GNU Public Licence.]
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <string.h>
#include "der.h"
#include "apps.h"
#include "err.h"
#include "x509.h"
#include "x509_obj.h"
#include "pem.h"

#define MAX_OBJECTS	20

#define PROG	req_main

/* -inform arg	- input format - default PEM (one of DER, TXT or PEM)
 * -outform arg - output format - default PEM
 * -in arg	- input file - default stdin
 * -out arg	- output file - default stdout
 * -verify	- check request signature
 * -noout	- don't print stuff out.
 * -text	- print out human readable text.
 * -generate key- make a request.
 * -keyform	- generate request key format
 */

#ifdef PROTO
int make_REQ(X509_REQ *req,RSA *rsa);
int add_object(X509_NAME *n, char *text, char *def, int nid);
int ASN1_PRINTABLE_type(unsigned char *s);
#else
int make_REQ();
int add_object();
int ASN1_PRINTABLE_type();
#endif

int MAIN(argc, argv)
int argc;
char **argv;
	{
	X509_REQ *req;
	RSA *rsa;
	int i,badops=0;
	FILE *in,*out;
	int informat,outformat,verify=0,noout=0,text=0,keyform=FORMAT_PEM;
	char *infile,*outfile,*prog,*generate=NULL;

	infile=NULL;
	outfile=NULL;
	informat=FORMAT_PEM;
	outformat=FORMAT_PEM;

	prog=argv[0];
	argc--;
	argv++;
	while (argc >= 1)
		{
		if 	(strcmp(*argv,"-inform") == 0)
			{
			if (--argc < 1) goto bad;
			informat=str2fmt(*(++argv));
			}
		else if (strcmp(*argv,"-outform") == 0)
			{
			if (--argc < 1) goto bad;
			outformat=str2fmt(*(++argv));
			}
		else if (strcmp(*argv,"-generate") == 0)
			{
			if (--argc < 1) goto bad;
			generate= *(++argv);
			}
		else if (strcmp(*argv,"-keyform") == 0)
			{
			if (--argc < 1) goto bad;
			keyform=str2fmt(*(++argv));
			}
		else if (strcmp(*argv,"-in") == 0)
			{
			if (--argc < 1) goto bad;
			infile= *(++argv);
			}
		else if (strcmp(*argv,"-out") == 0)
			{
			if (--argc < 1) goto bad;
			outfile= *(++argv);
			}
		else if (strcmp(*argv,"-verify") == 0)
			verify=1;
		else if (strcmp(*argv,"-noout") == 0)
			noout=1;
		else if (strcmp(*argv,"-text") == 0)
			text=1;
		else
			{
			fprintf(stderr,"unknown option %s\n",*argv);
			badops=1;
			break;
			}
		argc--;
		argv++;
		}

	if (badops)
		{
bad:
		fprintf(stderr,"%s [options] <infile >outfile\n",prog);
		fprintf(stderr,"where options  are\n");
		fprintf(stderr," -inform arg    input format - one of DER TXT PEM\n");
		fprintf(stderr," -outform arg   output format - one of DER TXT PEM\n");
		fprintf(stderr," -in arg        inout file\n");
		fprintf(stderr," -out arg       output file\n");
		fprintf(stderr," -text          text form of request\n");
		fprintf(stderr," -noout         do not output REQ\n");
		fprintf(stderr," -verify        verify signature on REQ\n");
		fprintf(stderr," -generate key  generate a new certificate request using key\n");
		fprintf(stderr," -keyform arg	generate key format\n");
		EXIT(1);
		}

	ERR_load_crypto_strings();

	req=X509_REQ_new();

	if (generate != NULL)
		{
		in=fopen(generate,"r");
		if (in == NULL)
			{
			perror(generate);
			EXIT(1);
			}
		rsa=RSA_new();
		/* if (rsa == NULL) {} */
		if (keyform == FORMAT_DER)
			i=D2i_RSAPrivateKey_fp(in,rsa);
		else if (keyform == FORMAT_TEXT)
			i=f2i_RSAPrivateKey(in,rsa);
		else if (keyform == FORMAT_PEM)
			i=PEM_read_RSA(in,rsa);
		else
			{
			fprintf(stderr,"bad input format specified for X509 request\n");
			EXIT(1);
			}
		if (!i)
			{
			fprintf(stderr,"unable to load RSA key\n");
			ERR_print_errors(stderr);
			EXIT(1);
			}
		fclose(in);
		i=make_REQ(req,rsa);
		if (!i)
			{
			fprintf(stderr,"problems making Certificate Request\n");
			ERR_print_errors(stderr);
			EXIT(1);
			}
		}
	else
		{
		if (infile == NULL)
			in=stdin;
		else
			{
			in=fopen(infile,"r");
			if (in == NULL)
				{
				perror(infile);
				EXIT(1);
				}
			}

		if	(informat == FORMAT_DER)
			i=D2i_X509_REQ_fp(in,req);
		else if (informat == FORMAT_TEXT)
			i=f2i_X509_REQ(in,req);
		else if (informat == FORMAT_PEM)
			i=PEM_read_X509_REQ(in,req);
		else
			{
			fprintf(stderr,"bad input format specified for X509 request\n");
			EXIT(1);
			}
		if (!i)
			{
			fprintf(stderr,"unable to load X509 object\n");
			ERR_print_errors(stderr);
			EXIT(1);
			}
		}

	if (verify)
		{
		i=X509_REQ_verify(req);
		if (i < 0)
			{
			ERR_print_errors(stderr);
			EXIT(1);
			}
		else if (i == 0)
			{
			ERR_print_errors(stderr);
			fprintf(stderr,"verify failure\n");
			}
		else /* if (i > 0) */
			fprintf(stderr,"verify OK\n");
		}

	if (noout && !text) goto done;

	if (outfile == NULL)
		out=stdout;
	else
		{
		out=fopen(outfile,"w");
		if (out == NULL)
			{
			perror(outfile);
			EXIT(1);
			}
		}

	if (text) X509_REQ_print(out,req);;

	if (!noout)
		{
		if 	(outformat == FORMAT_DER)
			i=i2D_X509_REQ_fp(out,req);
		else if (outformat == FORMAT_TEXT)
			{ i2f_X509_REQ(out,req); i=1; }
		else if (outformat == FORMAT_PEM)
			i=PEM_write_X509_REQ(out,req);
		else	{
			fprintf(stderr,"bad output format specified for outfile\n");
			EXIT(1);
			}
		if (!i)
			{
			fprintf(stderr,"unable to write X509 request\n");
			ERR_print_errors(stderr);
			EXIT(1);
			}
		}
	if (out != stdout) fclose(out);
done:
	if (in != stdin) fclose(in);
	EXIT(0);
	}

int make_REQ(req,rsa)
X509_REQ *req;
RSA *rsa;
	{
	int ret=0,i;
	unsigned char *s,*p;
	DER_OBJECT *obj;
	X509_REQ_INFO *ri;
	
	ri=req->req_info;

	fprintf(stderr,"You are about to be asked to enter information that will be submitted\n");
	fprintf(stderr,"for a certificate request.\n");
	fprintf(stderr,"What you are entering is what is called a Distinguished Name or a DN.\n");
	fprintf(stderr,"There are quite a few field but you can leave some blank if you\n");
	fprintf(stderr,"so desire.  For all field there will be an example default value,\n");
	fprintf(stderr,"If you enter '.', the field will be left blank.  The fields you will\n");
	fprintf(stderr,"be prompted for (and examples are as follows).\n");
	fprintf(stderr,"Country Name [AU]\n");
	fprintf(stderr,"State or Province [QLD]\n");
	fprintf(stderr,"Locality Name []\n");
	fprintf(stderr,"Organisation Name [Mincom Pty Ltd]\n");
	fprintf(stderr,"Organisation Unit Name [ST]\n");
	fprintf(stderr,"Common Name [eay]\n");
	fprintf(stderr,"-----\n");

	/* setup version number */
	ri->version->length=1;
	ri->version->data=(unsigned char *)malloc(1);
	if (ri->version->data == NULL) goto err;
	ri->version->data[0]=0; /* version == 0 */

	/* do subject */
	/* this is sort of ugly, we should not have to know about the
	 * internals of the X509_NAME type object :-(.
	 * I'm just allocating space for 20 'objects' */
	ri->subject->objects=(DER_OBJECT **)
		malloc(sizeof(DER_OBJECT *)*MAX_OBJECTS);
	ri->subject->types=(int *)malloc(sizeof(int)*MAX_OBJECTS);
	ri->subject->values=(DER_BIT_STRING **)
		malloc(sizeof(DER_OBJECT *)*MAX_OBJECTS);
	if (	(ri->subject->objects == NULL) ||
		(ri->subject->values == NULL) ||
		(ri->subject->types == NULL))
		{
		fprintf(stderr,"malloc failure\n");
		goto err;
		}

	if (!add_object(ri->subject,"Country Name","AU",NID_countryName))
		goto err;
	if (!add_object(ri->subject,
		"State or Province","QLD",NID_stateOrProcinceName))
		goto err;
	if (!add_object(ri->subject,
		"Locality Name","",NID_localityName))
		goto err;
	if (!add_object(ri->subject,
		"Organisation Name","Mincom Pty Ltd",NID_organizationName))
		goto err;
	if (!add_object(ri->subject,
		"Organisation Unit Name","ST",NID_organizationalUnitName))
		goto err;
	if (!add_object(ri->subject,"Common Name","",NID_commonName))
		goto err;

	/* don't ever free the 'ri' object because it contins pointers
	 * into the 'object hash' area of the library. */

	/* copy public key */
	obj=X509_dup_DER_OBJECT(X509_nid2obj(NID_rsaEncryption));
	if (obj == NULL) goto err;
	DER_OBJECT_free(ri->pubkey->algor->algorithm);
	ri->pubkey->algor->algorithm=obj;

	i=i2D_RSAPublicKey(rsa,NULL);
	s=(unsigned char *)malloc((unsigned int)i+1);
	if (s == NULL)
		{
		fprintf(stderr,"malloc failure\n");
		goto err;
		}
	p=s;
	i2D_RSAPublicKey(rsa,&p);
	ri->pubkey->public_key->length=i;
	ri->pubkey->public_key->data=s;

	if (!X509_REQ_sign(req,rsa,PEM_MD_MD5_RSA))
		goto err;

	ret=1;
err:
	return(ret);
	}

int add_object(n,text,def,nid)
X509_NAME *n;
char *text;
char *def;
int nid;
	{
	int ret=0,i,j;
	static char buf[1024];

	fprintf(stderr,"%s [%s]:",text,def);
	fflush(stderr);
	buf[0]='\0';
	fgets(buf,1024,stdin);
	if (buf[0] == '\0') return(0);
	else if (buf[0] == '\n')
		{
		if ((def == NULL) || (def[0] == '\0'))
			return(1);
		strcpy(buf,def);
		strcat(buf,"\n");
		}
	else if ((buf[0] == '.') && (buf[1] == '\n')) return(1);

	i=strlen(buf);
	if (buf[i-1] != '\n')
		{
		fprintf(stderr,"weird input :-(\n");
		return(0);
		}
	buf[--i]='\0';

	j=n->num;
	/* add object plus value */
	n->objects[j]=X509_nid2obj(nid);
	X509_set_name_type(n->types[j],ASN1_PRINTABLE_type(buf));
	X509_set_name_set(n->types[j],n->num);
	n->values[j]=DER_BIT_STRING_new();
	if (n->values[j] == NULL) goto err;
	n->values[j]->length=i;
	n->values[j]->data=(unsigned char *)malloc(i+1);
	if (n->values[j]->data == NULL)
		{
		fprintf(stderr,"malloc failure\n");
		goto err;
		}
	memcpy(n->values[j]->data,buf,i+1);
	n->num++;
	ret=1;
err:
	return(ret);
	}

int ASN1_PRINTABLE_type(s)
unsigned char *s;
        {
        int c;

        while (*s)
                {
                c= *(s++);
                if (!(  ((c >= 'a') && (c <= 'z')) ||
                        ((c >= 'A') && (c <= 'Z')) ||
                        (c == ' ') ||
                        ((c >= '0') && (c <= '9')) ||
                        (c == ' ') || (c == '\'') ||
                        (c == '(') || (c == ')') ||
                        (c == '+') || (c == ',') ||
                        (c == '-') || (c == '.') ||
                        (c == '/') || (c == ':') ||
                        (c == '=') || (c == '?')))
                        return(DER_T61STRING);
                }
        return(DER_PRINTABLESTRING);
        }

