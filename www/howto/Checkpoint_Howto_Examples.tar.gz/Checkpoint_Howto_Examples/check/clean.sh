#!/bin/sh
#
# clean.sh
#

#
# Delete the checkpoint directory for this job.
#

me=`basename $0`

# test number of args
if [ $# -ne 2 ]; then
   echo "$me: got wrong number of arguments" >&2
   exit 1
fi

SGE_CKPT_JOB=$1/$2

if [ \! -d "$SGE_CKPT_JOB" ] ; then
    echo "Checkpoint subdirectory couldn't be found."
    exit 1
fi

rm -rf $SGE_CKPT_JOB

exit 0
