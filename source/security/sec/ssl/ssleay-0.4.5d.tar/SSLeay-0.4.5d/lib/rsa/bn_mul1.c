/* lib/rsa/bn_mul1.c */
/* Copyright (C) 1995 Eric Young (eay@mincom.oz.au)
 * All rights reserved.
 * 
 * This file is part of an SSL implementation written
 * by Eric Young (eay@mincom.oz.au).
 * The implementation was written so as to conform with Netscapes SSL
 * specification.  This library and applications are
 * FREE FOR COMMERCIAL AND NON-COMMERCIAL USE
 * as long as the following conditions are aheared to.
 * 
 * Copyright remains Eric Young's, and as such any Copyright notices in
 * the code are not to be removed.  If this code is used in a product,
 * Eric Young should be given attribution as the author of the parts used.
 * This can be in the form of a textual message at program startup or
 * in documentation (online or textual) provided with the package.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by Eric Young (eay@mincom.oz.au)
 * 
 * THIS SOFTWARE IS PROVIDED BY ERIC YOUNG ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * 
 * The licence and distribution terms for any publically available version or
 * derivative of this code cannot be changed.  i.e. this code cannot simply be
 * copied and put under another distribution licence
 * [including the GNU Public Licence.]
 */

#include <stdio.h>
#include "crypto.h"
#include "bn.h"

#define			LBITS(a)	((a)&MASK2l)
#define			HBITS(a)	(((a)>>BITS4)&MASK2l)
#define			L2HBITS(a)	(((a)&MASK2l)<<BITS4)

/* r must be different to a and b */
int bn_mul(r, a, b)
BIGNUM *r;
BIGNUM *a;
BIGNUM *b;
	{
	int i,j;
	int max;
	BN_ULONG *ap,*bp,*rp;

	max=(a->top+b->top+1);
	if (bn_expand(r,(max+1)*BITS2) == NULL) return(0);
	bn_zero(r);
	r->top=max;
	r->neg=a->neg^b->neg;
	bp=b->d;

	for (i=0; i<b->top; i++)
		{
		BN_ULONG m,c1,c2;

		c1=c2=0;
		rp= &(r->d[i]);
		ap=a->d;
		m =*(bp++);
		for (j=a->top; j; j--)
			{
			register BN_ULONG l,h,m2;
#ifndef RSA_LLONG
			register BN_ULONG T,m3;
			
			m3=LBITS(m);
			T =HBITS(m);
			l =LBITS(*ap);
			h =HBITS(*ap);
			ap++;

			m2=T *l;		/* m1 = h(a)*l(b) */
			l =m3*l;		/* l = l(a)*l(b) */
			m3=m3*h;		/* m2= l(a)*h(b) */
			h= T *h;		/* h = h(m)*h(b) */

			m2+=m3;			/* M = m1 + m2 */

			h+=HBITS(m2);		/* H = h + h(M) */
			if ((m2&MASK2) < m3) h+=L2HBITS(1L);

			m2=L2HBITS(m2);
			l+=m2;   if ((l&MASK2) < m2) h++;
			l+= *rp; if ((l&MASK2) < *rp) h++;
			l&=MASK2;
			h&=MASK2;
			m2=(l+c1)&MASK2;
			*(rp++)=m2;
			c1=(h+c2)&MASK2;
			if (m2 < l) c1++;
			c2=(c1 < h)?1:0;
#else
			BN_ULLONG t;

			t=(BN_ULLONG)m* *(ap++) + *rp;
			l=(BN_ULONG)t&MASK2;

			h=(t>>BITS2)&MASK2;
			m2=(l+c1)&MASK2;
			*(rp++)=m2;
			c1=(h+c2)&MASK2;
			if (m2 < l) c1++;
			c2=(c1 < h)?1:0;
#endif
			}
		*rp = c1;
		}
	bn_fix_top(r);
	return(1);
	}

