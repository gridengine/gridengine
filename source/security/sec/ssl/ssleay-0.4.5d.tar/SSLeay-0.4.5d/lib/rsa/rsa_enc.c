/* lib/rsa/rsa_enc.c */
/* Copyright (C) 1995 Eric Young (eay@mincom.oz.au)
 * All rights reserved.
 * 
 * This file is part of an SSL implementation written
 * by Eric Young (eay@mincom.oz.au).
 * The implementation was written so as to conform with Netscapes SSL
 * specification.  This library and applications are
 * FREE FOR COMMERCIAL AND NON-COMMERCIAL USE
 * as long as the following conditions are aheared to.
 * 
 * Copyright remains Eric Young's, and as such any Copyright notices in
 * the code are not to be removed.  If this code is used in a product,
 * Eric Young should be given attribution as the author of the parts used.
 * This can be in the form of a textual message at program startup or
 * in documentation (online or textual) provided with the package.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by Eric Young (eay@mincom.oz.au)
 * 
 * THIS SOFTWARE IS PROVIDED BY ERIC YOUNG ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * 
 * The licence and distribution terms for any publically available version or
 * derivative of this code cannot be changed.  i.e. this code cannot simply be
 * copied and put under another distribution licence
 * [including the GNU Public Licence.]
 */

#ifndef RSAref

#include <stdio.h>
#include "crypto.h"
#include "bn.h"
#include "buffer.h"
#include "md5.h"
#include "x509.h"

int RSA_public_encrypt(flen, from, to, rsa)
int flen;
unsigned char *from;
unsigned char *to;
RSA *rsa;
	{
	BIGNUM *f,*ret;
	int tos,i,j,k,btos,num;
	unsigned char *p;
	BUFFER *buf;

	tos=bn_get_tos();
	btos=buffer_get_tos();
	num=bn_num_bytes(rsa->n);
	if (flen > (num-11))
		{
		RSAerr(RSA_F_RSA_PUBLIC_ENCRYPT,RSA_R_DATA_TO_LARGE);
		goto err;
		}
	
	buf=buffer_get_buf();
	if ((buf == NULL) || (buffer_grow(buf,num) ==0))
		{
		RSAerr(RSA_F_RSA_PUBLIC_ENCRYPT,ERR_R_MALLOC_FAILURE);
		goto err;
		}
	ret=bn_get_reg();
	if (ret == NULL) goto err;
	p=(unsigned char *)buf->data;

	*(p++)=0;
	*(p++)=2; /* Public Key BT (Block Type) */

	/* pad out with non-zero random data */
	j=num-3-flen;
	MD5_rand(j,p);
	for (i=0; i<j; i++)
		{
		if (*p == '\0')
			do	{
				MD5_rand(1,p);
				} while (*p == '\0');
		p++;
		}
	*(p++)='\0';
	memcpy(p,from,(unsigned int)flen);
	f=bn_get_reg();
	if (f == NULL) goto err;
	if (bn_bin2bn(num,(unsigned char *)buf->data,f) == NULL) goto err;
	if (!bn_mod_exp(ret,f,rsa->e,rsa->n)) goto err;

	/* put in leading 0 bytes if the number is less than the
	 * length of the modulus */
	j=bn_num_bytes(ret);
	i=bn_bn2bin(ret,&(to[num-j]));
	for (k=0; k<(num-i); k++)
		to[k]=0;

	bn_set_tos(tos);
	bn_clean_up();
	buffer_set_tos(btos);
	buffer_clean_up();
	return(num);
err:
	bn_set_tos(tos);
	bn_clean_up();
	buffer_set_tos(btos);
	buffer_clean_up();
	return(0);
	}

int RSA_private_encrypt(flen, from, to, rsa)
int flen;
unsigned char *from;
unsigned char *to;
RSA *rsa;
	{
	BIGNUM *f,*ret;
	int tos,i,j,k,num,btos;
	unsigned char *p;
	BUFFER *buf;

	tos=bn_get_tos();
	btos=buffer_get_tos();
	num=bn_num_bytes(rsa->n);
	if (flen > (num-11))
		{
		RSAerr(RSA_F_RSA_PRIVATE_ENCRYPT,RSA_R_DATA_TO_LARGE);
		goto err;
		}
	buf=buffer_get_buf();
	if ((buf == NULL) || (buffer_grow(buf,num) <= 0))
		{
		RSAerr(RSA_F_RSA_PRIVATE_ENCRYPT,ERR_R_MALLOC_FAILURE);
		goto err;
		}
	ret=bn_get_reg();
	if (ret == NULL) goto err;
	p=(unsigned char *)buf->data;

	*(p++)=0;
	*(p++)=1; /* Private Key BT (Block Type) */

	/* padd out with 0xff data */
	j=num-3-flen;
	for (i=0; i<j; i++)
		*(p++)=0xff;
	*(p++)='\0';
	memcpy(p,from,(unsigned int)flen);
	f=bn_get_reg();
	if (f == NULL) goto err;
	if (bn_bin2bn(num,(unsigned char *)buf->data,f) == NULL) goto err;
	if (	(rsa->p != NULL) &&
		(rsa->q != NULL) &&
		(rsa->dmp1 != NULL) &&
		(rsa->dmq1 != NULL) &&
		(rsa->iqmp != NULL))
		{ if (!RSA_mod_exp(ret,f,rsa)) goto err; }
	else
		{ if (!bn_mod_exp(ret,f,rsa->d,rsa->n)) goto err; }

	p=(unsigned char *)buf->data;
	i=bn_bn2bin(ret,p);

	/* put in leading 0 bytes if the number is less than the
	 * length of the modulus */
	j=bn_num_bytes(ret);
	i=bn_bn2bin(ret,&(to[num-j]));
	for (k=0; k<(num-i); k++)
		to[k]=0;

	bn_set_tos(tos);
	bn_clean_up();
	buffer_set_tos(btos);
	buffer_clean_up();
	return(num);
err:
	bn_set_tos(tos);
	bn_clean_up();
	buffer_set_tos(btos);
	buffer_clean_up();
	return(-1);
	}

int RSA_private_decrypt(flen, from, to, rsa)
int flen;
unsigned char *from;
unsigned char *to;
RSA *rsa;
	{
	BIGNUM *f,*ret;
	int tos,i,j,num,btos;
	unsigned char *p;
	BUFFER *buf;

	tos=bn_get_tos();
	btos=buffer_get_tos();
	num=bn_num_bytes(rsa->n);

	buf=buffer_get_buf();
	if ((buf == NULL) || (buffer_grow(buf,num) <= 0))
		{
		RSAerr(RSA_F_RSA_PRIVATE_DECRYPT,ERR_R_MALLOC_FAILURE);
		goto err;
		}

	if (flen != num)
		{
		RSAerr(RSA_F_RSA_PRIVATE_DECRYPT,RSA_R_DATA_NOT_EQ_TO_MOD_LEN);
		goto err;
		}

	/* make data into a big number */
	f=bn_get_reg();
	if (f == NULL) goto err;
	if (bn_bin2bn((int)flen,from,f) == NULL) goto err;
	/* do the decrypt */
	ret=bn_get_reg();
	if (ret == NULL) goto err;
	if (	(rsa->p != NULL) &&
		(rsa->q != NULL) &&
		(rsa->dmp1 != NULL) &&
		(rsa->dmq1 != NULL) &&
		(rsa->iqmp != NULL))
		{ if (!RSA_mod_exp(ret,f,rsa)) goto err; }
	else
		{ if (!bn_mod_exp(ret,f,rsa->d,rsa->n)) goto err; }

	p=(unsigned char *)buf->data;
	i=bn_bn2bin(ret,p);

	/* BT must be 02 */
	if (*(p++) != 02)
		{
		RSAerr(RSA_F_RSA_PRIVATE_DECRYPT,RSA_R_BLOCK_TYPE_IS_NOT_02);
		goto err;
		}

	/* scan over padding data */
	j=num-2; /* one for type and one for the prepended 0. */
	for (i=0; i<j; i++)
		if (*(p++) == 0) break;
	if (i == j)
		{
		RSAerr(RSA_F_RSA_PRIVATE_DECRYPT,
			RSA_R_NULL_BEFORE_BLOCK_MISSING);
		goto err;
		}
	if (i < 8)
		{
		RSAerr(RSA_F_RSA_PRIVATE_DECRYPT,RSA_R_BAD_PAD_BYTE_COUNT);
		goto err;
		}

	/* skip over the '\0' */
	i++;	
	j-=i;

	/* output data */
	memcpy(to,p,(unsigned int)j);
	bn_set_tos(tos);
	bn_clean_up();
	buffer_set_tos(btos);
	buffer_clean_up();
	return(j);
err:
	bn_set_tos(tos);
	bn_clean_up();
	buffer_set_tos(btos);
	buffer_clean_up();
	return(-1);
	}

int RSA_public_decrypt(flen, from, to, rsa)
int flen;
unsigned char *from;
unsigned char *to;
RSA *rsa;
	{
	BIGNUM *f,*ret;
	int tos,i,j,num,btos;
	unsigned char *p;
	BUFFER *buf;

	tos=bn_get_tos();
	btos=buffer_get_tos();
	num=bn_num_bytes(rsa->n);
	buf=buffer_get_buf();
	if ((buf == NULL) || (buffer_grow(buf,num) <= 0))
		{
		RSAerr(RSA_F_RSA_PUBLIC_DECRYPT,ERR_R_MALLOC_FAILURE);
		goto err;
		}

	if (flen != num)
		{
		RSAerr(RSA_F_RSA_PUBLIC_DECRYPT,RSA_R_DATA_NOT_EQ_TO_MOD_LEN);
		goto err;
		}
	/* make data into a big number */
	f=bn_get_reg();
	if (f == NULL) goto err;
	if (bn_bin2bn(flen,from,f) == NULL) goto err;
	/* do the decrypt */
	ret=bn_get_reg();
	if (ret == NULL) goto err;
	if (!bn_mod_exp(ret,f,rsa->e,rsa->n)) goto err;

	p=(unsigned char *)buf->data;
	i=bn_bn2bin(ret,p);

	/* BT must be 01 */
	if (*(p++) != 01)
		{
		RSAerr(RSA_F_RSA_PUBLIC_DECRYPT,RSA_R_BLOCK_TYPE_IS_NOT_01);
		goto err;
		}

	/* scan over padding data */
	j=num-2; /* one for type and one for the prepended 0. */
	for (i=0; i<j; i++)
		{
		if (*p != 0xff) /* should decrypt to 0xff */
			{
			if (*p == 0)
				{ p++; break; }
			else	{
				RSAerr(RSA_F_RSA_PUBLIC_DECRYPT,
					RSA_R_BAD_FF_HEADER);
				goto err;
				}
			}
		p++;
		}
	if (i == j)
		{
		RSAerr(RSA_F_RSA_PUBLIC_DECRYPT,
			RSA_R_NULL_BEFORE_BLOCK_MISSING);
		goto err;
		}
	if (i < 8)
		{
		RSAerr(RSA_F_RSA_PUBLIC_DECRYPT,RSA_R_BAD_PAD_BYTE_COUNT);
		goto err;
		}

	/* skip over the '\0' */
	i++;	
	j-=i;

	/* output data */
	memcpy(to,p,(unsigned int)j);
	bn_set_tos(tos);
	bn_clean_up();
	buffer_set_tos(btos);
	buffer_clean_up();
	return(j);
err:
	bn_set_tos(tos);
	bn_clean_up();
	buffer_set_tos(btos);
	buffer_clean_up();
	return(-1);
	}

#else
#include "../rsaref/rsaref.c"
#endif

