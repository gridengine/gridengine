#!/bin/sh
# check_transparent2.sh

trap 'echo $ACTUAL_VALUE > $SGE_CKPT_DIR/checkpoint_2' usr2

#
# Check whether we are restarted and a checkpoint file is already avaiualble.
#

if [ "$RESTARTED" -eq "1" -a -e "$SGE_CKPT_DIR/checkpoint_2" -a -r "$SGE_CKPT_DIR/checkpoint_2" ] ; then
    read ACTUAL_VALUE < $SGE_CKPT_DIR/checkpoint_2
    echo "Script restarted with value $ACTUAL_VALUE."
else
    ACTUAL_VALUE=1
    echo "Script started."
fi

#
# Start of the program.
#

while [ "$ACTUAL_VALUE" -le 1000 ] ; do
    echo "Processing $ACTUAL_VALUE."
    let ACTUAL_VALUE++
    sleep 1
done

echo "Script finished."

exit 0
