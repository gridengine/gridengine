/* lib/buffer/buffer.c */
/* Copyright (C) 1995 Eric Young (eay@mincom.oz.au)
 * All rights reserved.
 * 
 * This file is part of an SSL implementation written
 * by Eric Young (eay@mincom.oz.au).
 * The implementation was written so as to conform with Netscapes SSL
 * specification.  This library and applications are
 * FREE FOR COMMERCIAL AND NON-COMMERCIAL USE
 * as long as the following conditions are aheared to.
 * 
 * Copyright remains Eric Young's, and as such any Copyright notices in
 * the code are not to be removed.  If this code is used in a product,
 * Eric Young should be given attribution as the author of the parts used.
 * This can be in the form of a textual message at program startup or
 * in documentation (online or textual) provided with the package.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by Eric Young (eay@mincom.oz.au)
 * 
 * THIS SOFTWARE IS PROVIDED BY ERIC YOUNG ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * 
 * The licence and distribution terms for any publically available version or
 * derivative of this code cannot be changed.  i.e. this code cannot simply be
 * copied and put under another distribution licence
 * [including the GNU Public Licence.]
 */

#include <stdio.h>
#include "crypto.h"
#include "buffer.h"

#define BUFFER_INC	4

static int num_buffers=0;
static int buf_tos=0;
static BUFFER **bufs=NULL;

void buffer_clean_up()
	{
	int i;

	for (i=buf_tos; i<num_buffers; i++)
		{
		memset(bufs[i]->data,0,(unsigned int)bufs[i]->length);
		free(bufs[i]);
		}
	num_buffers=buf_tos;
	}

BUFFER *buffer_new()
	{
	BUFFER *ret;

	ret=(BUFFER *)malloc(sizeof(BUFFER));
	if (ret == NULL)
		{
		X509err(X509_F_BUFFER_NEW,ERR_R_MALLOC_FAILURE);
		return(NULL);
		}
	ret->length=0;
	ret->data=NULL;
	return(ret);
	}

void buffer_free(a)
BUFFER *a;
	{
	if (a->data) free(a->data);
	free(a);
	}

int buffer_grow(str, len)
BUFFER *str;
long len;
	{
	char *ret;

	if (str->length >= len) return(len);
	if (str->data == NULL)
		ret=(char *)malloc((unsigned int)len);
	else
		ret=(char *)realloc(str->data,(unsigned int)len);
	if (ret == NULL)
		{
		X509err(X509_F_BUFFER_GROW,ERR_R_MALLOC_FAILURE);
		ret=str->data;
		len=0;
		}
	else
		{
		str->data=ret;
		str->length=len;
		}
	return(len);
	}

int buffer_get_tos()
	{
	return(buf_tos);
	}

void buffer_set_tos(a)
int a;
	{
	buf_tos=a;
	}

BUFFER *buffer_get_buf()
	{
	int i;
	BUFFER **bp;

	if (bufs == NULL)
		{
		num_buffers=0;
		bufs=(BUFFER **)malloc(sizeof(BUFFER *));
		if (bufs == NULL)
			{
			X509err(X509_F_BUFFER_GET_BUF,ERR_R_MALLOC_FAILURE);
			return(NULL);
			}
		buf_tos=0;
		}
	if (buf_tos >= num_buffers)
		{
		i=num_buffers;
		num_buffers+=BUFFER_INC;
		bp=(BUFFER **)realloc(bufs,sizeof(BUFFER *)*num_buffers);
		if (bp == NULL)
			{
			X509err(X509_F_BUFFER_GET_BUF,ERR_R_MALLOC_FAILURE);
			return(NULL);
			}
		bufs=bp;
		for (; i<num_buffers; i++)
			{
			bufs[i]=buffer_new();
			if (bufs[i] == NULL) return(NULL);
			}
		}
	return(bufs[buf_tos++]);
	}

