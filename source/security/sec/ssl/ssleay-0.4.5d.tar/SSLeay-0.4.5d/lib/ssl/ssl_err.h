/* lib/ssl/ssl_err.h */
/* Copyright (C) 1995 Eric Young (eay@mincom.oz.au)
 * All rights reserved.
 * 
 * This file is part of an SSL implementation written
 * by Eric Young (eay@mincom.oz.au).
 * The implementation was written so as to conform with Netscapes SS
 * specification.  This library and applications are
 * FREE FOR COMMERCIAL AND NON-COMMERCIAL USE
 * as long as the following conditions are aheared to.
 * 
 * Copyright remains Eric Young's, and as such any Copyright notices in
 * the code are not to be removed.  If this code is used in a product,
 * Eric Young should be given attribution as the author of the parts used.
 * This can be in the form of a textual message at program startup or
 * in documentation (online or textual) provided with the package.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by Eric Young (eay@mincom.oz.au)
 * 
 * THIS SOFTWARE IS PROVIDED BY ERIC YOUNG ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIA
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * 
 * The licence and distribution terms for any publically available version or
 * derivative of this code cannot be changed.  i.e. this code cannot simply be
 * copied and put under another distribution licence
 * [including the GNU Public Licence.]
 */

#include "err.h"

#ifndef HEADER_SSL_ERR_H
#define HEADER_SSL_ERR_H

#define SSL_F_NO_ERROR				0
#define SSL_F_SSL_NEW				1
#define SSL_F_SSL_CERT_NEW			2
#define SSL_F_GET_SERVER_HELLO			3
#define SSL_F_CLIENT_HELLO			4
#define SSL_F_CLIENT_MASTER_KEY			5
#define SSL_F_CLIENT_CERTIFICATE		6
#define SSL_F_GET_SERVER_VERIFY			7
#define SSL_F_GET_SERVER_FINISHED		8
#define SSL_F_GET_NEW_CONN			9
#define SSL_F_SSL_ENC_DES_CBC_INIT		10
#define SSL_F_SSL_ENC_DES_EDE3_CBC_INIT		11
#define SSL_F_SSL_ENC_DES_CFB_INIT		12
#define SSL_F_SSL_ENC_NULL_INIT			13
#define SSL_F_SSL_ENC_RC4_INIT			14
#define SSL_F_SSL_CERT_RSA_PUBLIC_ENCRYPT	15
#define SSL_F_SSL_CERT_RSA_PRIVATE_ENCRYPT	16
#define SSL_F_SSL_CERT_RSA_PUBLIC_DECRYPT	17
#define SSL_F_SSL_CERT_RSA_PRIVATE_DECRYPT	18
#define SSL_F_SSL_USE_CERTIFICATE		19
#define SSL_F_SSL_USE_CERTIFICATE_DER		20
#define SSL_F_SSL_USE_RSAPRIVATEKEY		21
#define SSL_F_SSL_USE_RSAPRIVATEKEY_DER		22
#define SSL_F_SSL_EXTRACT_PUBLIC_KEY		23
#define SSL_F_SSL_SET_CERTIFICATE		24
#define SSL_F_GET_CLIENT_MASTER_KEY		25
#define SSL_F_GET_CLIENT_HELLO			26
#define SSL_F_SERVER_HELLO			27
#define SSL_F_GET_CLIENT_FINISHED		28
#define SSL_F_REQUEST_CERTIFICATE		29
#define SSL_F_SSL_ENC_IDEA_CBC_INIT		30
#define SSL_F_SSL_USE_RSAPRIVATEKEY_FILE	31
#define SSL_F_SSL_WRITE				32
#define SSL_F_DECODE_RECORD			33
#define SSL_F_SSL_CONNECT			34
#define SSL_F_SSL_READ				35
#define SSL_F_SSL_ACCEPT			36
#define SSL_F_SSL_USE_CERTIFICATE_FILE		37

/* non-fatal errors */
#define SSL_R_SHORT_READ			1
#define SSL_R_PEER_ERROR			2
#define SSL_R_READ_WRONG_PACKET_TYPE		3
#define SSL_R_NO_CIPHER_LIST			4
#define SSL_R_NO_CIPHER_MATCH			5
#define SSL_R_PUBLIC_KEY_ENCRYPT_ERROR		6
#define SSL_R_CHALLENGE_IS_DIFFERENT		7
#define SSL_R_SESSION_ID_IS_DIFFERENT		8
#define SSL_R_BAD_MAC_DECODE			9
#define SSL_R_NO_PUBLICKEY			10
#define SSL_R_NO_PRIVATEKEY			11
#define SSL_R_BAD_X509_FILETYPE			12
#define SSL_R_BAD_SESSION_ID_LENGTH		13
#define SSL_R_NO_CERTIFICATE_SPECIFIED		14
#define SSL_R_CONNECTION_ID_IS_DIFFERENT	15
#define SSL_R_PEER_DID_NOT_RETURN_A_CERT 	16
#define SSL_R_BAD_CHECKSUM			17
#define SSL_R_BAD_CHECKSUM_DECODE		18
#define SSL_R_BAD_WRITE_RETRY			19
#define SSL_R_BAD_AUTHENTICATION_TYPE		20

/* fatal errors */
#define SSL_R_BAD_STATE				(30|ERR_R_FATAL)
#define SSL_R_CIPHER_TABLE_SRC_ERROR		(31|ERR_R_FATAL)
#define SSL_R_UNKNOWN_STATE			(32|ERR_R_FATAL)

#endif
