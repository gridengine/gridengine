#!/bin/sh

mv configur	Configure
mv copyrigh	COPYRIGHT
mv rambling	RAMBLINGS
mv files	FILES
mv porting	PORTING
mv readme	README
mv readme.044	README.044
mv todo		TODO
mv version	VERSION

for i in makefile.ssl */makefile.ssl */*/makefile.ssl
do
	mv $i `dirname $i`/Makefile.ssl
done

/bin/rm -f makefile */makefile */*/makefile

chmod a+rx Configure
chmod a+rx util/*.sh

for i in test/testx509 test/testrsa test/testcrl test/testgen
do
	chmod a+rx $i
done

chmod a+rx certs/tools/*
# (cd certs; tools/c_rehash *.pem)
make -f Makefile.ssl links
make -f Makefile.ssl clean

