#!/bin/sh

from=$1
shift

here=`pwd`
tmp=`dirname $from`
while [ "$tmp"x != "x" -a "$tmp"x != ".x" ]
do
	t=`basename $here`
	here=`dirname $here`
	to="/$t$to"
	tmp=`dirname $tmp`
done
to=..$to

#echo from=$from
#echo to  =$to
#exit 1

if [ "$*"x != "x" ]; then
	for i in $*
	do
		/bin/rm -f $from/$i
		ln -s $to/$i $from/$i
	done
fi
exit 0;
