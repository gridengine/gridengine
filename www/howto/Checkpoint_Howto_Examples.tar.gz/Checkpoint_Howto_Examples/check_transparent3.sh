#!/bin/sh
# check_transparent3.sh

trap '' usr2

SGE_CKPT_JOB=$SGE_CKPT_DIR/$JOB_ID

if [ \! -e "$SGE_CKPT_JOB" ] ; then
    mkdir $SGE_CKPT_JOB
fi

if [ \! -d "$SGE_CKPT_JOB" ] ; then
    echo "Checkpoint subdirectory couldn't be found."
    exit 1
fi

#
# Check whether we are restarted.
#

if [ "$RESTARTED" -eq "1" ] ; then
    /home/reuti/checkpoint_program3 -r -d $SGE_CKPT_JOB
else
    /home/reuti/checkpoint_program3 -d $SGE_CKPT_JOB
fi

rm -rf $SGE_CKPT_JOB

exit 0
