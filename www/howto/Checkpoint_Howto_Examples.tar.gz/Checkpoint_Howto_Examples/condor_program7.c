/******************************************
*                                         *
* Demonstration program for checkpointing *
*            condor_program7.c            *
*                                         *
******************************************/

#include <stdio.h>
#include <unistd.h>
#include <sys/stat.h>
#include <math.h>

#define TRUE 1
#define FALSE 0

static char        checkpoint_directory[255];
static char        checkpoint_name[]="/checkpoint_7";

struct checkpoint_struct {

    short    position;
    float    values[1000];
} computing;

/********************************
*                               *
* Initialization of the program *
*                               *
********************************/

void init_program(struct checkpoint_struct *value)
{
    value->position=0;
}

/***************************
*                          *
* Main program starts here *
*                          *
***************************/

int main(int argc, char **argv)
{
    int         option;
    static char option_string[]=":d:r";
    int         checkpoint_enabled=FALSE;
    int         restarted=FALSE;

    int         i;

    long        mytimer;

    struct stat sbuf;

    char        checkpoint_read[255];

/********************************
*                               *
* Process the command line args *
*                               *
********************************/

    while ((option = getopt(argc, argv, option_string)) != -1)
        switch (option)
        {
            case 'r':
                restarted=TRUE;
                break;
            case 'd':
                strcpy(checkpoint_directory, optarg);
                if (stat(checkpoint_directory, &sbuf) != 0)
                {
                    fprintf(stderr, "Couldn't stat %s.\n", checkpoint_directory);
                    abort();
                }
                if (S_ISDIR(sbuf.st_mode))
                    checkpoint_enabled=TRUE;
                break;
            default:
                fprintf(stderr, "Unknown option: %s.\n", argv[optind-1]);
                abort();
        }              

/*******************************************
*                                          *
* Test for restart without given directory *
*                                          *
*******************************************/

    if (restarted && !checkpoint_enabled)
        fprintf(stderr, "Can't restart without given directory. Request ignored.\n");

/*****************************
*                            *
* Enable the checkpoint file *
*                            *
*****************************/

    if (checkpoint_enabled)
    {
        strcpy(checkpoint_read, checkpoint_directory);
        strcat(checkpoint_read, checkpoint_name);

        init_image_with_file_name(checkpoint_read);
        fprintf(stderr, "Update: Condor: Notice: Will checkpoint to %s\n", checkpoint_read);
    }

/**********************************
*                                 *
* Access the last checkpoint file *
*                                 *
**********************************/

    if (restarted && checkpoint_enabled)
    {
        fprintf(stderr, "I will try to restart...\n");

        if (stat(checkpoint_read, &sbuf) != 0)
        {
            fprintf(stderr,"No checkpoint file written up to now. Restart from the beginning.\n");
            init_program(&computing);
        }
        else
            restart();
    }
    else
        init_program(&computing);

/************************
*                       *
* Now start the program *
*                       *
************************/

    computing.position=0;

    for ( ; computing.position < 1000; computing.position++)
    {
        computing.values[computing.position] = sqrt(computing.position);
        mytimer=time();
        while (mytimer == time())
            ;
}

/*********************
*                    *
* Output the results *
*                    *
*********************/

    for (i=0; i < 1000; i++)
        printf("sqrt(%d) = %f\n", i, computing.values[i]);

/*********************
*                    *
* End of the program *
*                    *
*********************/

    return(0);
}
