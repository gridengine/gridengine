#!/bin/sh
# condor_transparent6.sh

trap '' usr2

SGE_CKPT_JOB=$SGE_CKPT_DIR/$JOB_ID

if [ \! -e "$SGE_CKPT_JOB" ] ; then
    mkdir $SGE_CKPT_JOB
fi

if [ \! -d "$SGE_CKPT_JOB" ] ; then
    echo "Checkpoint subdirectory couldn't be found."
    exit 1
fi

#
# Check whether we are restarted.
#

SGE_CKPT_FILE=$SGE_CKPT_JOB/checkpoint_6

if [ "$RESTARTED" -eq "1" -a -e "$SGE_CKPT_FILE" -a -r "$SGE_CKPT_FILE" ] ; then
    /home/reuti/condor_program6 -_condor_restart $SGE_CKPT_FILE
else
    /home/reuti/condor_program6 -_condor_ckpt $SGE_CKPT_FILE
fi

rm -rf $SGE_CKPT_JOB

exit 0
